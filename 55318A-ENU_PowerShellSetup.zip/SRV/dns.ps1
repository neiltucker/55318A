dnscmd /zoneadd 10.168.192.in-addr.arpa /dsprimary
dnscmd /zoneadd 20.168.192.in-addr.arpa /dsprimary
Set-DNSServerPrimaryZone -Name "contoso.com" -DynamicUpdate "NonsecureAndSecure" -PassThru
Set-DNSServerPrimaryZone -Name "10.168.192.in-addr.arpa" -DynamicUpdate "NonsecureAndSecure" -PassThru
Set-DNSServerPrimaryZone -Name "20.168.192.in-addr.arpa" -DynamicUpdate "NonsecureAndSecure" -PassThru
Add-DNSServerResourceRecord -CName -Name "sharepoint" -HostNameAlias "lon-dc1.contoso.com" -ZoneName "contoso.com" -AllowUpdateAny
Add-DNSServerResourceRecord -CName -Name "mail" -HostNameAlias "lon-dc1.contoso.com" -ZoneName "contoso.com" -AllowUpdateAny
Add-DNSServerResourceRecordMX -Preference 10 -Name "." -MailExchange "mail.contoso.com" -ZoneName "contoso.com"
net stop dns
net start dns
Get-DNSServerRootHint | Remove-DNSServerRootHint -Force
Add-DNSServerRootHint -NameServer "lon-dc1.contoso.com" -IPAddress 192.168.10.101
net stop netlogon
net start netlogon