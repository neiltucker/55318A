Install-WindowsFeature -IncludeManagementTools DHCP
Netsh dhcp add securitygroups
Restart-Service DHCPSERVER
Add-DHCPServerInDC LON-DC1 192.168.10.101
netsh dhcp server import C:\Classfiles\dhcpdb12 all