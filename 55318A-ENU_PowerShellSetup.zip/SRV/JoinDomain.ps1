# Join server to the Contoso domain.  If the process fails, reboot and try again.
# Check if computer is already a part of Contoso.com
$RunOncePath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
if ((Get-WmiObject -Class Win32_ComputerSystem).PartOfDomain) {reg import C:\Classfiles\SRV\run3.reg ; reg import C:\Classfiles\SRV\LocalLogonAdminz.reg ; shutdown /r /t 1}
# Add computer to the Contoso.com domain
Get-DNSClientServerAddress | Where {$_.InterfaceAlias -like "Ethernet*"} | Set-DNSClientServerAddress -ServerAddresses ("192.168.10.100")
do {
  Write-Host "Testing connection to Contoso.com domain controller ..."
  Start-Sleep 5      
} until(Test-NetConnection 192.168.10.100 -Port 135 | ? {$_.TcpTestSucceeded})
$DomainUser = 'Adminz'
$DomainPassword = Write-Output 'Pa$$w0rdPa$$w0rd' | ConvertTo-SecureString -AsPlainText -Force
$Credentials = New-Object PSCredential ($DomainUser, $DomainPassword)
$AD = Add-Computer -DomainName Contoso.com -Credential $Credentials -Passthru -Verbose
if ($AD.HasSucceeded) {reg import C:\Classfiles\SRV\run3.reg ; reg import C:\Classfiles\SRV\LocalLogonAdminz.reg} else {reg import C:\Classfiles\SRV\run3.reg ; shutdown /r /t 1}
Start-Sleep 10

