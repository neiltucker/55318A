echo off
cls
echo "*****   Upgrading SQL Server 2019 Default Instance   *****"
echo "*****   Please wait while components are configured (15 - 30 minutes)   *****"
echo .
echo .
echo .
D:\SQLServer\SQL2019\Setup.exe /INDICATEPROGRESS /IACCEPTSQLSERVERLICENSETERMS /Q /CONFIGURATIONFILE=C:\Classfiles\SQL_Software_Installu.INI
