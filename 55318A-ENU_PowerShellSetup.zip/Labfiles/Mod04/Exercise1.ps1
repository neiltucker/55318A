﻿## Lesson 1: Understanding error handling
## Monitoring and capturing errors

# Step 1: Notice how errors are handled when the ErrorAction setting is change.  
# Note: The default error action preference is: Continue
$Error.Clear()
$ErrorActionPreference
Get-Process -Name 'Invalid-PS1' -ErrorVariable PS1 -ErrorAction Continue 
Get-Process -Name 'Invalid-PS2' -ErrorVariable PS2 -ErrorAction Stop
Get-Process -Name 'Invalid-PS3' -ErrorVariable PS3 -ErrorAction Inquire
Get-Process -Name 'Invalid-PS4' -ErrorVariable PS4 -ErrorAction SilentlyContinue
Get-Process -Name 'Invalid-PS5' -ErrorVariable PS5 -ErrorAction Ignore
Get-Process -Name 'Invalid-PS6' -ErrorVariable PS6 -ErrorAction Suspend

# Note: The error action 'Inquire' response will change the outcome.
$Error
$Error.Count
$Error[0]
$Error[-1]
$Error[0] | GM 
Foreach ($e in $Error) {
$e | Select-Object CategoryInfo, Exception, ErrorRecord | Format-List
}

$PS1 | Select-Object Exception, ErrorRecord
$PS2 | Select-Object Exception, ErrorRecord
$PS3 | Select-Object Exception, ErrorRecord
$PS4 | Select-Object Exception, ErrorRecord
$PS5 | Select-Object Exception, ErrorRecord
$PS6 | Select-Object Exception, ErrorRecord



# Step 2: Change the $EA variable to try all 6 possible error actions in the Try statement.  Notice how the outputs in the Catch and Finally statements change accordingly.
# Note: The $_ variable will only make error details available in the Catch statement regardless of the error action.
# Note: Only terminating errors are managed in the catch statement.
$EA = 'Continue'
$CN = 'Invalid-Computer'
Try { 
Write-Output "Try 1"
$Computer = Get-CimInstance Win32_BIOS –ComputerName $CN –ErrorAction $EA 
Write-Output "Try 2"
} 
Catch {
Write-Output "Catch 1"
Write-Warning "Unable to connect to: $CN" 
Write-Output "Catch 2"
Write-Output ":::" $_
} 
Finally { 
 Write-Output "Finally 1"
 Write-Output "Finally: Try/Catch complete." 
 Write-Output "Finally 2"
 Write-Output ":::" $_
 } 


# Step 3: Use Get-Error to capture error data.  Get-Error is a PowerShell Core command.
# PowerShell ISE does not support PowerShell Core.  Each command in this step must be run individually in a new "Administrator: PowerShell" console or on "Visual Studio Code" with the PowerShell Extension. 
# Before using error commands and variables in PowerShell Core, you will verify that you are using Windows PowerShell (Version 5.X), switch to PowerShell Core (pwsh) then verify you are using Powershell Core (Version 7.x).
# Note: Get-Error support for pipeline inputs depend on whether ErrorRecord or Exception objects are provided.
$PPSersionTable
pwsh
$PPSersionTable
$Error.Count
Get-Process -Name 'Invalid-PS1' -ErrorVariable PS1 -ErrorAction Continue 
Get-Process -Name 'Invalid-PS2' -ErrorVariable PS2 -ErrorAction Stop
Get-Process -Name 'Invalid-PS3' -ErrorVariable PS3 -ErrorAction Inquire
Get-Process -Name 'Invalid-PS4' -ErrorVariable PS4 -ErrorAction SilentlyContinue
Get-Process -Name 'Invalid-PS5' -ErrorVariable PS5 -ErrorAction Ignore
Get-Process -Name 'Invalid-PS6' -ErrorVariable PS6 -ErrorAction Suspend

$Error.Count
$Error
$Error[0] | gm
Foreach ($e in $Error) {
$e | Select-Object CategoryInfo, Exception, ErrorRecord | Format-List
}

$PS1 | Select-Object Exception, ErrorRecord
$PS2 | Select-Object Exception, ErrorRecord
$PS3 | Select-Object Exception, ErrorRecord
$PS4 | Select-Object Exception, ErrorRecord
$PS5 | Select-Object Exception, ErrorRecord
$PS6 | Select-Object Exception, ErrorRecord

Get-Error 
Get-Error -Newest 5
$Error | Get-Error 
$ErrorInfo = $Error | Get-Error 
$ErrorInfo[0] | GM -MemberType Property 
Foreach ($i in $ErrorInfo) {
$i | Select-Object Message, Exception, ErrorRecord | FL
}
