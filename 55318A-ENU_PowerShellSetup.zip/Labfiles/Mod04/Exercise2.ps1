﻿## Lesson 2: Handling errors in a script
## Adding error handling code to scripts and functions
## Adding error message data to files and the Event Log

# Step 1: Use the Trap statement to prevent a function from displaying invalid data.
function Get-BIOSInfo1 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Trap { Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop }
    $BI
}

Get-BIOSInfo1
# Try removing the Trap statement to see how the function runs.  The terminating error will prevent the viewing of any data.


# Step 2: Use the Try/Catch statement to prevent a function from displaying invalid data.
function Get-BIOSInfo2 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Try {Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop}
    Catch {Write-Output "There was an error writing BIOS information to the Event Log."}
    Finally {$BI}
}

Get-BIOSInfo2
# Without the Try/Catch block, you will have the same problem as with the first function.  A terminating error will prevent any data from being displayed after execution.


# Step 3: Log error data to a text file.  Include date and time information.
function Get-BIOSInfo3 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $FilePath ="C:\Classfiles\Mod04Lesson2Step3.log"
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Try {Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop}
    Catch {Write-Output "There was an error writing BIOS information to the Event Log."
           "[{0:yyyy-MM-dd} {0:HH:mm:ss}]" -f (Get-Date) | Out-File -FilePath $FilePath -Append ; $_ | Out-File -FilePath $FilePath -Append
          }
    Finally {$BI}
}

Get-BIOSInfo3
# Check the log file in the location specified by the $FilePath variable


# Step 4: Write error information to the application Event Log
# Note: All events are written to a "Source" name which often specifies the application generating the message.  This can be done with the New-EventLog command.
New-EventLog –LogName Application –Source “BIOSInfo4”
function Get-BIOSInfo4 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $FilePath ="C:\Classfiles\Mod04Lesson2Step3.log"
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Try {Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop}
    Catch {Write-Output "There was an error writing BIOS information to the Event Log."
           Write-EventLog -LogName Application -Source "BIOSInfo4" -EntryType Error -EventID 1000 -Message $_
          }
    Finally {$BI}
}

Get-BIOSInfo4
# Check the Application Event Log for errors that match your application "Source"
Get-EventLog -LogName Application -Source "BIOSInfo4" 

