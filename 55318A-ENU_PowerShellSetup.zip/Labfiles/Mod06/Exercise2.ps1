﻿## Lesson 2: Implementing JEA
## Configuring and using JEA for DNS Administration on LON-DC1
## This exercise must be performed from LON-SRV1

# Step 1: Create a new JEA role capabilities file with the name C:\Classfiles\DNSAdmin.psrc 
Set-Location C:\Classfiles
New-PSRoleCapabilityFile -Path C:\Classfiles\DNSAdmin.psrc 


# Step 2: Edit the DNSAdmin.psrc file in Notepad to change and enable the following fields.
# Enable parameters by removing the leading '#' ahead of the parameter setting 
# A sample DNSAdmin.psrc file is in the C:\Classfiles\Tools folder 
ModulesToImport = 'Microsoft.PowerShell.Core', 'DNSServer'
VisibleCmdlets = 'Get-DNSServer', 'Test-DNSServer', 'Get-Service', @{Name = 'Restart-Service'; Parameters = @{ Name = 'Name'; ValidateSet = 'DNS'}}
VisibleExternalCommands ='C:\Windows\system32\dnscmd.exe', 'C:\Windows\System32\netstat.exe', 'C:\Windows\System32\ipconfig.exe', 'C:\Windows\System32\ping.exe', 'C:\Windows\System32\hostname.exe', 'C:\Windows\System32\whoami.exe'


# Step 3: Save the updated role capabilities script to the "RoleCapabilities" folder on LON-DC1.
$ModuleFolder = Join-Path -Path $env:ProgramFiles -ChildPath "WindowsPowerShell\Modules\ContosoJEA"
$RCFolder = Join-Path -Path $ModuleFolder -ChildPath "RoleCapabilities"
Invoke-Command -ScriptBlock {New-Item -ItemType Directory -Path $using:RCFolder -ErrorAction SilentlyContinue} -ComputerName LON-DC1

# Create empty script module
Invoke-Command -ScriptBlock {New-Item -ItemType File -Path $using:ModuleFolder -Name "ContosoJEAFunctions.psm1" -ErrorAction SilentlyContinue} -ComputerName LON-DC1
Invoke-Command -ScriptBlock {New-ModuleManifest -Path $using:ModuleFolder"\ContosoJEA.psd1" -RootModule "ContosoJEAFunctions.psm1"} -ComputerName LON-DC1

# Copy RoleCapabilities (PSRC) file and verify it was copied successfully
$LONDC1 = New-PSSession -ComputerName LON-DC1
Copy-Item -Path C:\Classfiles\DNSAdmin.psrc -Destination $RCFolder -ToSession $LONDC1
Invoke-Command -ScriptBlock {Get-Content $using:RCFolder"\DNSAdmin.psrc"} -Session $LONDC1


# Step 4: Create and test a new JEA session file with the name C:\Classfiles\DNSAdmin.pssc using the specified parameters.  Copy it to the same location on LON-DC1
# The RoleCapabilities parameter will map to the name of the .psrc file
New-PSSessionConfigurationFile -Path C:\Classfiles\DNSAdmin.pssc -SessionType RestrictedRemoteServer -ExecutionPolicy Restricted -TranscriptDirectory C:\Classfiles\Transcripts -RunAsVirtualAccount -RoleDefinitions @{'Contoso\Student' = @{RoleCapabilities = 'DNSAdmin'}}
Test-PSSessionConfigurationFile -Path C:\Classfiles\DNSAdmin.pssc
Get-Content -Path C:\Classfiles\DNSAdmin.pssc
Copy-Item -Path C:\Classfiles\DNSAdmin.pssc -Destination \\LON-DC1\C$\Classfiles


# Step 5: Register the JEA session using the DNSAdmin.pssc file 
# You may need to restart the WinRM service on the LON-DC1 server (e.g., Invoke-Command -ScriptBlock {Restart-Service WinRM} -ComputerName LON-DC1)
Invoke-Command -ScriptBlock {Register-PSSessionConfiguration -Path C:\Classfiles\DNSAdmin.pssc -Name 'JEADNSAdmin'} -ComputerName LON-DC1


# Step 6: Test the session on the LON-DC1 server.  
# Try all the commands specified in the VisibleCmdlets and VisibleExternalCommands fields from the roles file.
# Note: the ModulesToImport option will be ignored unless the two enabled Visible fields are disabled.
Enter-PSSession -ComputerName LON-DC1 -ConfigurationName 'JEADNSAdmin'

# Test the following commands in the JEADNSAdmin session
whoami
dns
Get-DNSServer 
Test-DNSServer 
Get-Service 
Restart-Service
Restart-Service DNS
dnscmd
ipconfig
netstat


# Step 7: Review the transcript directory files in C:\Classfiles\Transcripts using Notepad to learn details about your connection(s).

# If time permits, test other commands not listed to verify that they fail.  
# If time permits, test disabling the VisibleCmdlets and VisibleExternalCommands fields in the DNSAdmin.psrc file to enable ModulesToImport
