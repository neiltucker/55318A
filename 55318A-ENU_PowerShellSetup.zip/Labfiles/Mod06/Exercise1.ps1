﻿## Lesson 1: Implementing DSC
## DSC configuraiton files and resources

# Step 1: Check the DSC Configuration mode setting for both LON-SRV1 and LON-DC1.
$Servers = Import-CSV C:\Classfiles\ComputerNames.txt | New-PSSession
$Servers 
Invoke-Command -Session $Servers -ScriptBlock {Get-DscLocalConfigurationManager}


# Step 2: Create a DSC configuration file that will change the DSCLocalConfiguration mode to "ApplyandAutoCorrect".  
# Review the DscLocalConfig.ps1 and DscMode.ps1 scripts before continuing.
Invoke-Command -Session $Servers -ScriptBlock {C:\Classfiles\DscMode.ps1}
Invoke-Command -Session $Servers -ScriptBlock {Get-DscLocalConfigurationManager}


# Step 3: Review the C:\Classfiles\AutoCorrectConfig directory.  This is the name assigned to the configuration in the DscLocalConfig.ps1 file.
# It will store the MOF file for the local server.  Take note of the ConfigurationMode in each file.
Invoke-Command -Session $Servers -ScriptBlock {Get-ChildItem C:\Classfiles\AutoCorrectConfig}
Invoke-Command -Session $Servers -ScriptBlock {Get-Content C:\Classfiles\AutoCorrectConfig\*.mof}


# Step 4: Update the DSC configuration and verify the change to the ConfigurationMode.
Invoke-Command -Session $Servers -ScriptBlock {Set-WSManQuickConfig -Force}
Invoke-Command -Session $Servers -ScriptBlock {Set-DscLocalConfigurationManager -Path C:\Classfiles\AutoCorrectConfig}
Invoke-Command -Session $Servers -ScriptBlock {Get-DscLocalConfigurationManager}
 

# Step 5: Install the Print-Services and Storage-Replica features on LON-SRV1 & LON-DC1 using DSC
# First, verify that the features are not already installed.
# Review the DscLocalPrintServer.ps1 and DscLocalPrintAndStore.ps1 scripts before continuing.
# Ignore any request to reboot the system.
Invoke-Command -Session $Servers -ScriptBlock {Get-WindowsFeature "Print-Services", "Storage-Replica"}
Invoke-Command -Session $Servers -ScriptBlock {C:\Classfiles\DscLocalPrintServer.ps1}

Invoke-Command -Session $Servers -ScriptBlock {Get-ChildItem C:\Classfiles\PrintAndStore}
Invoke-Command -Session $Servers -ScriptBlock {Get-Content C:\Classfiles\PrintAndStore\*.mof}

Invoke-Command -Session $Servers -ScriptBlock {Start-DscConfiguration -Path C:\Classfiles\PrintAndStore -Wait -Verbose -Force}
Invoke-Command -Session $Servers -ScriptBlock {Get-WindowsFeature "Print-Services", "Storage-Replica"}


