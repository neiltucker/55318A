﻿## Lesson 2: Analyzing and debugging an existing script
## Debugging code manually and with tools
## The solution script is C:\Classfiles\Tools\EventLog.ps1

# Step 1: Debug the code in the C:\Classfiles\Tools\EventLog_tst.ps1 script file.  It must meet the objectives stated in the comment lines of the script.  
Get-Content C:\Classfiles\Tools\EventLog_tst.ps1

# Step 2: Exeucute the Get-BIOSInfo7 function in the script to verify that the changes worked.
# Verify that the Event Log has 3001 messages in the Application log.
Get-BIOSInfo7 -ComputerName LON-DC1, LON-SRV1
Get-EventLog -LogName Application -Source "BIOSInfo7" -Newest 2 | FL

