﻿## Lesson 1: Understanding Windows PowerShell Workflow
## Configuring the workflow environment on LON-DC1.  
## This exercise must be done from LON-SRV1.

# Step 1: Create a remote session on LON-DC1.  
# Configure the options for a new workflow session with the following options: Process Timeout: 15 seconds, Maximum Activity Processes: 10 and Maximum Sessions Per Workflow: 10 
# Assign the configuration to a variable
Enter-PSSession -ComputerName LON-DC1
Set-Location C:\Classfiles
$wf = New-PSWorkflowExecutionOption -ActivityProcessIdleTimeoutSec 30 -MaxActivityProcesses 10 -MaxSessionsPerWorkflow 10 


# Step 2: Register a new session with the new configuration and give it the name "WorkflowAdmin".
# Session configurations can be removed by unregistering them (e.g., Get-PSSessionConfiguration -Name WorkflowAdmin | UnRegister-PSSessionConfiguration)
Register-PSSessionConfiguration -Name WorkflowAdmin -SessionTypeOption $wf


# Step 3: List the details of the default workflow sessions and the new session.
Get-PSSessionConfiguration -Name "*workflow*" | Select-Object Name, ActivityProcessIdleTimeoutSec, MaxActivityProcesses, MaxSessionsPerWorkflow


# Step 4: Disconnect from LON-DC1 to restore local connection to LON-SRV1.  Make the default session name "WorkflowAdmin". 
# Note: The session name could also have been used by referring to it by name when creating a new session (e.g., New-PSSession -ComputerName LON-SRV1 -ConfigurationName WorkflowAdmin)
Exit-PSSession
$PSSessionConfigurationName
$PSSessionConfigurationName = "WorkflowAdmin"
$PSSessionConfigurationName
Get-Service -Name WinRM | Restart-Service


# Step 5: Create a new session on LON-DC1.  Verify that the session is using the new configuration.
Enter-PSSession -ComputerName LON-DC1
Set-Location C:\Classfiles
Get-PSSession -ComputerName LON-DC1

