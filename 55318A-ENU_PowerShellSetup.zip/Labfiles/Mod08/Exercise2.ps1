﻿## Lesson 2: Running Windows PowerShell Workflows
## Create and run Windows PowerShell Workflows on LON-DC1
## These steps should be run from LON-SRV1

# Step 1: Create a workflow named Start-SMTP.  It will start the SMTP service and verify that it is running.
# Do not execute the workflow in this step.
Workflow Start-SMTP { 
 [CmdletBinding()] 
 Param 
 ( 
 [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
 [String[]]$ComputerName
 )
 foreach ($computer in $ComputerName) {
   Get-Service -PSComputerName $computer -Name "SMTPSVC" | Start-Service
   if ((get-service -name "smtpsvc").Status -eq "Running") {Write-Output "SMTP Service is running on: $computer" }
   else {Write-Output "SMTP Service is not running on: $computer" }
  }
} 

gcm Start-SMTP 
Get-Command -CommandType Workflow


# Step 2: Save the workflow as a script named C:\Classfiles\StartSMTP.ps1.  Copy the script to the same location on LON-DC1.
# Sample StartSMTP.ps1 script is in the C:\Classfiles\Tools folder.
Get-Content C:\Classfiles\StartSMTP.ps1
$DC1Session = New-PSSession -ComputerName LON-DC1
Copy-Item -Path C:\Classfiles\StartSMTP.ps1 -Destination C:\Classfiles\StartSMTP.ps1 -ToSession $DC1Session 
Remove-PSSession -Session $DC1Session
Get-PSSession 


# Step 3: Compare the code in StartSMTP.ps1 to the code generated for Start-SMTP by PowerShell Workflow.
Get-Content C:\Classfiles\StartSMTP.ps1 
Get-Content Function:\Start-SMTP


# Step 4: Stop the SMTP service on LON-DC1.
Get-Service -Name "SMTPSVC" -ComputerName LON-DC1 | Stop-Service
Get-Service -Name "SMTPSVC" -ComputerName LON-DC1


# Step 5: Create a PowerShell Workflow session on LON-DC1 using the "WorkflowAdmin" configuration.
# To use the builtin workflow session, run the command: Enter-PSSession -ComputerName LON-SRV1 -ConfigurationName Microsoft.PowerShell.Workflow.
# New-PSWorkflowSession always uses the builtin configuration.  It is the same as running New-PSSession with Microsoft.PowerShell.Workflow as the configuration name option.
Invoke-Command -ComputerName LON-DC1 -ScriptBlock {Get-PSSessionConfiguration -Name "*workflow*"}
$WFServer = New-PSWorkflowSession -ComputerName LON-DC1 -ConfigurationName "WorkflowAdmin" 
Invoke-Command $WFServer {Import-Module -Name C:\Classfiles\StartSMTP.ps1}
Invoke-Command $WFServer {Start-SMTP -ComputerName LON-DC1 -AsJob -JobName "StartSMTPJob"}
Invoke-Command $WFServer {Get-Job} 
Invoke-Command $WFServer {Receive-Job -Name "StartSMTPJob"} 


# Step 6: Verify that the SMTP service was started.  Remove the workflow session.
Get-Service -Name "SMTPSVC"
Remove-PSSession -Session $WFServer
Get-PSSession 

# Step 7: If time permits, rewrite the workflow to work with multiple servers and test it using LON-DC1 as the workflow server.
# Start-SMTP -ComputerName LON-SRV1, LON-DC1

