﻿function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}

