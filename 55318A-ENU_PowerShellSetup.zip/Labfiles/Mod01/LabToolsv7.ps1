﻿function Get-DiskInfo {
<#
.SYNOPSIS
Retrieve computer hardware and operating system information.
.DESCRIPTION
Use the CIM instances of a class to gather information about network computers.
You will also be able to stop the Print Spooler Service and confirm its status.
.PARAMETER ComputerName
The name of the computer(s) from which you want hardware data.
.EXAMPLE
Get-DiskInfo -ComputerName LON-SRV1
This command will gather hardware and operating system information about the LON-SRV1 computer.
#>
    [CmdletBinding(SupportsShouldProcess=$True,ConfirmImpact='High')]  
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            if ($PSCmdlet.ShouldProcess($Computer,'Stop Spooler Service')){Get-Service -ComputerName $Computer -Name Spooler | Stop-Service -Force}
            $ss = Get-Service -ComputerName $Computer -Name Spooler
            $cdrive = Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer -Filter 'DeviceID = "C:"'
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'CDriveSize' = $cdrive.Size;
                'CDriveFreeSpace' = $cdrive.FreeSpace;                
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model;
                'SpoolerStatus' = $ss.Status} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}

