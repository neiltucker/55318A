﻿## Lesson 2: Creating a script module
## Convert a PowerShell script into a script module.
## Before starting, verify that $VerbosePreference="SilentlyContinue"

# Step 1: Remove the original function definition for Get-DiskInfo from memory
Get-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-DiskInfo

# Try to execute the function.  It should fail.
Get-DiskInfo


# Step 2: Save the function definition code as LabTools.psm1 in your personal modules folder
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools psm1 file from the first version of the existing ps1 file
<# Taken from the script: C:\Classfiles\LabFiles\Mod01\LabToolsv1.ps1 
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}
#>
Copy-Item -Path C:\Classfiles\LabFiles\Mod01\LabToolsv1.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Try to execute the function again.  It should succed.
Get-DiskInfo 
Get-DiskInfo -ComputerName 'LON-DC1'
Get-DiskInfo -ComputerName 'LON-DC1' -Verbose


# Step 3: Update the script module using version 2 of the ps1 file as shown below:
<# Taken from the script: C:\Classfiles\LabFiles\Mod01\LabToolsv2.ps1 
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Write-Verbose -Message "Now connecting to $ComputerName" -Verbose
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}
#>
Remove-Module LabTools
Copy-Item -Path C:\Classfiles\LabFiles\Mod01\LabToolsv2.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Try to execute the function again.  The -Verbose option will provide the details specified in the Write-Verbose line of the script.
Get-DiskInfo 
Get-DiskInfo -ComputerName 'LON-DC1'
Get-DiskInfo -ComputerName 'LON-SRV1','LON-DC1'
Get-DiskInfo -ComputerName 'LON-DC1' -Verbose
