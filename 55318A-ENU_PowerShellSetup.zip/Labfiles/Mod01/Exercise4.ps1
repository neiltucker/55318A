﻿## Lesson 4: Writing functions to accept pipeline input
## Processing pipeline vs non-pipeline parameter inputs

# Step 1: Remove the original function definitions from memory
Get-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-DiskInfo


# Step 2: Use the ValueFromPipelineByPropertyName option to use parameter names in the pipeline
function Get-DiskInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    ForEach ($Computer in $ComputerName) {
        Write-Output "Connecting to: $Computer"
        Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer
    }
}

Get-DiskInfo
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo


# Step 3: Duplicate the previous function using a PROCESS block
function Get-DiskInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Write-Output "Connecting to: $ComputerName"
        Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName
    }
}

Get-DiskInfo
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo


# Step 4: Use all three blocks for this function (BEGIN, PROCESS & END)
function Get-DiskInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    BEGIN {
        Write-Output "BEGIN script block: This function accepts computer names and provides the total physical memory available on the system:"
        Write-Output "Computer names processed in the BEGIN script block: $ComputerName"
    }
    PROCESS {
        Write-Output "PROCESS script block.  Connecting to: $ComputerName"
        Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName
    }
    END {
        Write-Output "END script block: "
        Write-Output "The last computer name processed is: $ComputerName"
    }
}

Get-DiskInfo
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo


# Step 5: Save the previous function as the new LabTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools file
Copy-Item -Path C:\Classfiles\Labfiles\Mod01\LabToolsv4.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Test the updated LabTools module script.  
# When prompted for the computer name, make sure to specify "!?" to see the help messages.
# Specify multiple computers names (lon-dc1, lon-srv1)
Remove-Module LabTools
Remove-Item -Path Function:\Get-DiskInfo
Get-DiskInfo 
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo
