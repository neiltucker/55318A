﻿## Lesson 3: Defining parameter attributes
## Define and validate parameter attributes

# Step 1: Remove any existing function definition for Get-DiskInfo from memory
Remove-Module LabTools
Get-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-DiskInfo


# Step 2: Define an advanced function with a string parameter
# Note: Some advanced parameter options require parameters with specific data types.
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName
}

Get-DiskInfo
Get-DiskInfo -Verbose


# Step 3: Make the parameter mandatory
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName
}

Get-DiskInfo


# Step 4: Add a help message to the mandatory parameter
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName
}

# When prompted for the computer name, make sure to specify "!?" to see the help message.
Get-DiskInfo


# Step 5: Create an alias for the parameter
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [Alias('ServerName')]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName
}

# Test the alias
Get-DiskInfo -ServerName lon-dc1


# Step 6: Add a second Parameter
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [Alias('ServerName')]
        [string]$ComputerName,
        [Parameter(Mandatory=$True,HelpMessage='This is a test parameter')]
        [int]$Parameter2
    )
    Write-Verbose "Connect to: $ComputerName"
    Write-Verbose "The second parameter is: $Parameter2"
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}

# Test the second parameter.  Try entering a non-integer value.
Get-DiskInfo -Verbose


# Step 7: Validate the input using the ValidateLength attribute
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [Alias('ServerName')]
        [ValidateLength(3,63)]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}

# Use a computer name with less than three (3) characters to test the ValidateLength attribute
Get-DiskInfo -ComputerName 'lo'
Get-DiskInfo -ComputerName 'lon'
Get-DiskInfo -ComputerName 'lon-srv1'


# Step 8: Accept multiple computer names in the function
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name(s) being queried')]
        [Alias('ServerName')]
        [ValidateLength(3,63)]
        [string[]]$ComputerName
    )
    foreach ($Computer in $ComputerName) {
        Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer 
    }
}

# Test the foreach configuration by inputing two computer names (lon-dc1 & lon-srv1)
Get-DiskInfo 


# Step 9: Save the previous function as the new LabTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools file
Copy-Item -Path C:\Classfiles\Labfiles\Mod01\LabToolsv3.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Test the updated LabTools module script.  
# When prompted for the computer name, make sure to specify "!?" to see the help messages.
# Specify multiple computers names (lon-dc1, lon-srv1)
Remove-Module LabTools
Remove-Item -Path Function:\Get-DiskInfo
Get-DiskInfo 
