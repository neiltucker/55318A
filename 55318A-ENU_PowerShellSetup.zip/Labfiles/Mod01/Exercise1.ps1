## Exercise 1: Converting a command into a function
## Create a function to display total and free disk space information for one or more computers on the network

# Step 1: Find an appropriate class to capture disk information and test it.
Get-CimClass -ClassName *disk*

# Test some of the class names
Get-CimInstance -ClassName CIM_DiskDrive
Get-CimInstance -ClassName CIM_DiskSpaceCheck
Get-CimInstance -ClassName Win32_DiskDrive
Get-CimInstance -ClassName Win32_LogicalDisk 
Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName 'lon-srv1','lon-dc1'


# Step 2: Use a basic parameter block to specify an optional parameter for -ComputerName
Param(
    [array]$ComputerName = @('lon-srv1','lon-dc1')
)
Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName


# Step 3: Create the function and add CmdletBinding capabilities
# Note: We will discuss ValueFromPipeline & ValueFromPipelineByPropertyName in a later lesson
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}


# Step 4: Test the previous function to make sure it returns disk information for multiple computers 
Get-DiskInfo
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-DiskInfo -ComputerName $_.ComputerName}
 

# Step 5: Test the function variable $CompuerName with and without dot-sourcing
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
$ComputerName

. Get-DiskInfo -ComputerName lon-srv1, lon-dc1
$ComputerName 


Note:  Dot sourcing is often used as a temporary solution as importing the functions or using script modules is more efficient 


