﻿## Lesson 5: Produce complex function output
## Create custom objects and write them to the pipeline

# Step 1: Remove the original function definitions from memory
Get-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-DiskInfo


# Step 2: Create a function that writes PowerShell objects to the pipeline
function Get-DiskInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            $cdrive = Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer -Filter 'DeviceID = "C:"'
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'CDriveSize' = $cdrive.Size;
                'CDriveFreeSpace' = $cdrive.FreeSpace;
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}


# Step 3: Test the objects in the PowerShell pipeline
# Note: The order in which you specify the object properties will be different from the order chosen by PowerShell.
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
$SysInfo = Get-DiskInfo -ComputerName lon-srv1, lon-dc1
$SysInfo | Get-Member
$SysInfo | Select-Object ComputerName, RAM


# Step 4: Save the previous function as the new LabTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools file
Copy-Item -Path C:\Classfiles\Labfiles\Mod01\LabToolsv5.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Test the updated LabTools module script.  
Remove-Module LabTools
Remove-Item -Path Function:\Get-DiskInfo
Get-DiskInfo -ComputerName lon-srv1, lon-dc1
$SysInfo = Get-DiskInfo -ComputerName lon-srv1, lon-dc1
$SysInfo | Get-Member
$SysInfo | Select-Object ComputerName, RAM

