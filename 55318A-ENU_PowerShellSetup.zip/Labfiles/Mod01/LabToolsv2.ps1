﻿function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Write-Verbose -Message "Now connecting to $ComputerName" -Verbose
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}
