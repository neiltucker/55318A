﻿## Lesson 6: Using comment-based Help
## Add comment-based Help to a function

# Step 1: Remove the original function definitions from memory
Get-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-DiskInfo


# Step 2: Create a function that uses comment-based Help.  This example puts the code at the beginning of the function
# Additional information about comment-based Help can be found using: help about_comment_based_help
function Get-DiskInfo {
<#
.SYNOPSIS
Retrieve computer hardware and software information.
.DESCRIPTION
Use the CIM instances of a class to gather information about network computers.
.PARAMETER ComputerName
The name of the computer(s) from which you want hardware data.
.EXAMPLE
Get-DiskInfo -ComputerName LON-SRV1
This command will gather hardware details from the LON-SRV1 computer.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            $cdrive = Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer -Filter 'DeviceID = "C:"'
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'CDriveSize' = $cdrive.Size;
                'CDriveFreeSpace' = $cdrive.FreeSpace;
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}


# Step 3: Test the comment-based Help for the function
Get-Help Get-DiskInfo 
Get-Help Get-DiskInfo -Detailed
Get-Help Get-DiskInfo -Examples


# Step 4: Save the previous function as the new LabTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools file
Copy-Item -Path C:\Classfiles\Labfiles\Mod01\LabToolsv6.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Test the updated LabTools module script.  
Remove-Module LabTools
Remove-Item -Path Function:\Get-DiskInfo
Get-Help Get-DiskInfo 
Get-Help Get-DiskInfo -Detailed
Get-Help Get-DiskInfo -Examples
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo 

