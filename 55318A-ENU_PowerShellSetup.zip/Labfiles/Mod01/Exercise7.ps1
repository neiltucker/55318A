﻿## Lesson 7: Using Whatif and Confirm parameters
## Enable the Whatif and Confirm parameters for an advanced function

# Step 1: Remove the original function definitions from memory and verify that the Print Spooler service is started on all servers.
Get-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-DiskInfo
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-Service -Name Spooler -ComputerName $_.ComputerName } | Start-Service -Verbose


# Step 2: Create a function that enables the use of the Whatif and Confirm parameters.
# You will modify the CmdletBinding option to include the SupportsShoudProcessing argument
function Get-DiskInfo {
<#
.SYNOPSIS
Retrieve computer hardware and operating system information.
.DESCRIPTION
Use the CIM instances of a class to gather information about network computers.
You will also be able to stop the Print Spooler Service and confirm its status.
.PARAMETER ComputerName
The name of the computer(s) from which you want hardware data.
.EXAMPLE
Get-DiskInfo -ComputerName LON-SRV1
This command will gather hardware and operating system information about the LON-SRV1 computer.
#>
    [CmdletBinding(SupportsShouldProcess=$True)]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            Get-Service -ComputerName $Computer -Name Spooler | Stop-Service -Force
            $ss = Get-Service -ComputerName $Computer -Name Spooler
            $cdrive = Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer -Filter 'DeviceID = "C:"'
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'CDriveSize' = $cdrive.Size;
                'CDriveFreeSpace' = $cdrive.FreeSpace;
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model;
                'SpoolerStatus' = $ss.Status} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}


# Step 3: Verify the Print Spooler services are running then test the Whatif and Confirm parameters
# Note: When the function runs successfully, this will stop the spooler service
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-Service -Name Spooler -ComputerName $_.ComputerName } | Start-Service -Verbose 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Whatif
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Confirm:$True
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Confirm:$False
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo


# Step 4: Create a function that enables the use of the ConfirmImpact option & the $GetCmdlet.ShouldProcess method to automatically use the confirm parameter.
# You will modify the CmdletBinding option to include the SupportsShoudProcessing argument
function Get-DiskInfo {
<#
.SYNOPSIS
Retrieve computer hardware and operating system information.
.DESCRIPTION
Use the CIM instances of a class to gather information about network computers.
You will also be able to stop the Print Spooler Service and confirm its status.
.PARAMETER ComputerName
The name of the computer(s) from which you want hardware data.
.EXAMPLE
Get-DiskInfo -ComputerName LON-SRV1
This command will gather hardware and operating system information about the LON-SRV1 computer.
#>
    [CmdletBinding(SupportsShouldProcess=$True,ConfirmImpact='High')]  
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            if ($PSCmdlet.ShouldProcess($Computer,'Stop Spooler Service')){Get-Service -ComputerName $Computer -Name Spooler | Stop-Service -Force}
            $ss = Get-Service -ComputerName $Computer -Name Spooler
            $cdrive = Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $Computer -Filter 'DeviceID = "C:"'
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'CDriveSize' = $cdrive.Size;
                'CDriveFreeSpace' = $cdrive.FreeSpace;                
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model;
                'SpoolerStatus' = $ss.Status} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}


# Step 5: Verify the Print Spooler services are running then test the Whatif and Confirm parameters
# Note: When the function runs successfully, this will stop the spooler service
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-Service -Name Spooler -ComputerName $_.ComputerName } | Start-Service -Verbose
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Whatif
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Confirm:$True
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Confirm:$False
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo


# Step 6: Save the previous function as the new LabTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the LabTools file
Copy-Item -Path C:\Classfiles\Labfiles\Mod01\LabToolsv7.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Test the updated LabTools module script.  
Remove-Module LabTools
Remove-Item -Path Function:\Get-DiskInfo
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-Service -Name Spooler -ComputerName $_.ComputerName } | Start-Service -Verbose
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Whatif
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Confirm:$True
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo -Confirm:$False
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo
