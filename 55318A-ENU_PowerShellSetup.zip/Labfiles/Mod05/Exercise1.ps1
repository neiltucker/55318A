﻿## Lesson 1: Working with XML formatted data
## Reading XML data and creating XML documents

# Step 1: Read 1 record from a SQL Server database table (AdventureWorks2019.Sales.vSalesPerson) and save the record in CSV and XML formatted files.
# Use both ConvertTo-Xml and Export-Clixml to create one XML file each.
# Note: You must first restore the AdventureWorks2019 database from a backup using the provided script.
# Note: Make sure the database is not in use before running the script.  If necessary, delete the existing database using SSMS.
C:\Classfiles\AdventureWorks_Install.ps1

$SalesTeam = Read-SqlViewData -ServerInstance $env:ComputerName -DatabaseName "AdventureWorks2019"  -SchemaName "Sales" -ViewName "vSalesPerson" -TopN 1 | `
 Select-Object FirstName,Lastname,PhoneNumber,EmailAddress
$SalesTeam
$SalesTeam | ConvertTo-CSV -NoTypeInformation | Out-File C:\Classfiles\salesteam1.csv
$SalesTeam | ConvertTo-Xml -As "Stream" | Out-File C:\Classfiles\salesteam1.xml
$SalesTeam | Export-Clixml -Path C:\Classfiles\salesteam2.xml 

Get-Content C:\Classfiles\salesteam1.csv
Get-Content C:\Classfiles\salesteam1.xml
Get-Content C:\Classfiles\salesteam2.xml


# Step 2: Read data from the ConvertTo-Xml file created.
Get-Content C:\Classfiles\salesteam1.xml 
Select-Xml -Path C:\Classfiles\salesteam1.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node} 
Select-Xml -Path C:\Classfiles\salesteam1.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.name}
Select-Xml -Path C:\Classfiles\salesteam1.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.'#text'}
Select-Xml -Path C:\Classfiles\salesteam1.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.InnerXml}
Select-Xml -Path C:\Classfiles\salesteam1.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.InnerText}


# Step 3: Reaad data from the Export-Clixml file and query it using Select-XML.  
Get-Content C:\Classfiles\salesteam2.xml
([xml](Get-Content C:\Classfiles\salesteam2.xml)).Objs.Obj.MS.S
$STxml = ([xml](Get-Content C:\Classfiles\salesteam2.xml))
$STxml.GetType()
$STxml.InnerXml
$STxml.Objs.Obj.MS.S | Select-Object '#text',N


# Step 4: Modify the XML document object
$STxml.Objs.Obj.MS.S
$PhoneNumber = $STxml.Objs.Obj.MS.S | Where {$_.N -eq "PhoneNumber"}
$PhoneNumber.InnerText = "123-456-7890"
$EmailAddress = $STxml.Objs.Obj.MS.S | Where {$_.N -eq "EmailAddress"}
$EmailAddress.InnerText = "admin@contoso.com"
$STxml.Objs.Obj.MS.S

# Step 5: Create PowerShell object from updated XMLDocument
$STxml.GetType()
$STxml.InnerXml | Out-File C:\Classfiles\salesteamupdate.xml
$STObj = Import-CliXml -Path C:\Classfiles\salesteamupdate.xml
$STObj
$STObj.GetType()


# Step 6: If time permits, try these steps in an Administrator:PowerShell console using PowerShell Core (pwsh).
