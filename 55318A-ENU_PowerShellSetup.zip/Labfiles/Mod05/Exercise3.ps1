﻿## Lesson 3: Working with custom-formatted data
## Using Regular Expressions
## PowerShell documentation on Regex: https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_regular_expressions

# Step 1: Use the Select-String statement to search all *.ps1 files in the C:\Classfiles folder for the phrase "download powershell version 7".
# What are the names of the files that have this statement and what are they used for?
# Test other regex expressions using Select-String
$Pattern = "download powershell version 7"
Select-String -Path C:\Classfiles\*.ps1 -Pattern $Pattern

Get-Content C:\Classfiles\55318_setup.ps1 | Select-String -Pattern $Pattern 
$Setupline = Get-Content C:\Classfiles\55318_setup.ps1 | Select-String -Pattern $Pattern 
Write-Output "The setup of PowerShell Core starts at line number: " $Setupline.LineNumber[0]

# Try other regex commands using Select-String
$SetupFiles = Get-Content C:\Classfiles\*.ps1
$SetupFiles -Match $Pattern
Select-String -Path C:\Classfiles\*.ps1 -Pattern $Pattern

Select-String -Path C:\Classfiles\*.ps1 -Pattern 'Download AdventureWorks'
Select-String -Path C:\Classfiles\*.ps1 -Pattern 'download adv*'

Select-String -Path C:\Classfiles\*.ps1 -Pattern 'Azure Modules'
Select-String -Path C:\Classfiles\*.ps1 -Pattern 'PowerShell Modules'

Select-String -Path C:\Classfiles\*.ps1 -Pattern 'Create Variables'
Get-ChildItem -Path C:\Classfiles\*.ps1 -Recurse | Select-String -Pattern 'Create Variables'

Get-ChildItem -Path C:\Classfiles\*.ps1 -Recurse | Select-String -Pattern '$Labfiles'
Get-ChildItem -Path C:\Classfiles\*.ps1 -Recurse | Select-String -Pattern '\$Labfiles'

Get-ChildItem -Path C:\Classfiles\*.ps1 -Recurse | Select-String -Pattern '5531[0-9]'
Get-ChildItem -Path C:\Classfiles\*.ps1 -Recurse | Select-String -Pattern '5531[^8]'
Get-ChildItem -Path C:\Classfiles\*.ps1 -Recurse | Select-String -Pattern '55315|55316|55318'


# Step 2: Use the Switch statement to search for a regex pattern for "download powershell version 7".
$SetupFile = Get-Content C:\Classfiles\55318_setup.ps1
Switch -Regex -CaseSensitive ($SetupFile)
{
  'download powershell version 7'
  {"The setup of PowerShell Core starts at line #: " ; $_.ReadCount ; Break}
  'Download PowerShell version 7'
  {"The Setup of PowerShell Core starts at line number: " ; $_.ReadCount ; Break}
}


# Step 3: Use the ConvertFrom-String statement to convert a CSV file into an object with named properties.
# Export Domain user informtion to a CSV file.  Rename the Name and UserPrincipalName columns to Employee and EmailAddress.
# Test other regex expressions
Get-AdUser -Filter * | Select-Object Name,UserPrincipalName | Export-CSV -NoTypeInformation -Path C:\Classfiles\adusers.csv
Get-Content C:\Classfiles\adusers.csv
[System.Collections.ArrayList]$AdUsers = Get-Content C:\Classfiles\adusers.csv
$AdUsers

# Remove 1st line with headers
$AdUsers.Remove($AdUsers[0])
$AdUsers

# Add column names using ConvertFrom-String
$AdUsers | ConvertFrom-String -Delimiter "\," -PropertyNames Employee, EmailAddress
$AdUsersObj = $AdUsers | ConvertFrom-String -Delimiter "\," -PropertyNames Employee, EmailAddress
$AdUsers.GetType()
$AdUsersObj.GetType()

# Try other regex commands 
88 -match '[0-8][5-9]'
84 -match '[0-8][5-9]'
'running' -match 'run[ner|ning]'
'runner' -match 'run[ner|ning]'

Get-ChildItem C:\Classfiles\*.csv
Get-ChildItem C:\Classfiles\*.backup
Get-ChildItem C:\Classfiles\*.csv | Copy-Item -Destination {$_.name -replace '\.csv$','.backup'}
Get-ChildItem C:\Classfiles\*.backup

$AdUsers -cmatch 'ADMIN*' 
$AdUsers -match 'ADMIN*'
$AdUsers -match 'admin[0-9]'
$AdUsers -match ',\"'
$AdUsers -match ',$'
$AdUsers -replace ',$', ',$_"@contoso.com"' -replace '","@','@'
$AdUsers2 = $AdUsers -replace ',$', ',$_"@contoso.com"' -replace '","@','@'
$AdUsers2
$AdUsersObj2 = $AdUsers2 | ConvertFrom-String -Delimiter "\," -PropertyNames Employee, EmailAddress


# Step 4: Use the ConvertFrom-StringData to create a hashtable from string data.  Use regex to format data source as a key=value structure.
$AdUsers2 
$AdUsers4 = $AdUsers2 -replace ',' , '='
$AdUsers4
$AdUsers4 | ConvertFrom-StringData 
$AdUsersHash4 = $AdUsers4 | ConvertFrom-StringData 
$AdUsersHash4


# Step 5: If time permits, try these steps in an Administrator:PowerShell console using PowerShell Core (pwsh).

