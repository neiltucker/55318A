﻿## Lesson 2: Writing controller scripts that show a user interface
## Create and test a controller script

# Step 1: Verify that the script module from the previous exercise was setup properly.
# If there are any errors, repeat the previous exercise.
Remove-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-MemoryInfo
Remove-Item -Path Function:\Get-SqlInfo
Get-Command -Module LabTools
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-SqlInfo 


# Step 2: Create and test the code that will be used for the controller script.  
# It will provide options to view server resources in three categories: (1) Logical Disk, (2) Computer System & (3) SQL Server instances
$Continue = $True
While ($Continue) {
    Write-Host "=================================="
    Write-Host "        SERVER RESOURCES          "
    Write-Host "=================================="
    Write-Host "                                  "
    Write-Host "1. Logical Disk                   "
    Write-Host "                                  "
    Write-Host "2. Computer System                "
    Write-Host "                                  "
    Write-Host "3. SQL Server Instances           "
    Write-Host "                                  "
    Write-Host "X. Exit                           "
    Write-Host "                                  "
    $input = Read-Host "Enter selection"
    Switch ($input) {
        "1" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo | Format-List}
        "2" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo | Format-List}
        "3" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-SQLInfo | Format-List}
        "X" {$Continue = $False}
        default {Write-Warning "Invalid Selection.  Try again."}
    }
}


# Step 3: Save the code as a script name C:\Classfiles\ServerResources.ps1 and verify that it works.
# A copy of the script is in the C:\Classfiles\Labfiles\Mod03 folder.
C:\Classfiles\ServerResources.ps1 
