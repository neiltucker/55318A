﻿## Lesson 3: Writing controller scripts that produce reports
## Create report for individual tool scripts
## Create report for multiple tool scripts


# Step 1: Create a report for each of the tool scripts used in the previous exercise.  Display each report as a list and size data columns in GB.  View each report in a web browser.
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo | Where-Object {$_.DriveType -eq 3} | ConvertTo-HTML -As List | Out-File C:\Classfiles\diskinfo.html
Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo | ConvertTo-HTML -As List | Out-File C:\Classfiles\memoryinfo.html 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-SQLInfo | ConvertTo-HTML -As List | Out-File C:\Classfiles\sqlinfo.html 

Invoke-Item C:\Classfiles\diskinfo.html
Invoke-Item C:\Classfiles\memoryinfo.html 
Invoke-Item C:\Classfiles\sqlinfo.html 


# Step 2: Create a table (fragment) for each tool script.
$DI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo | Where-Object {$_.DriveType -eq '3'} | `
 ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Disk Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$MI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo | ` 
 ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Computer System Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$SI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-SQLInfo | ` 
 ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>SQL Server Instance Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"


# Step 3: Combine the tables and include a report title and header.  Save and view the report (C:\Classfiles\ServerResources.html).
$Title = "<title>Server Resources Report</title>"
$Header = "<h1><b>Server Resources:</b></h1>"
$Head = $Title + $Header
$Body = $DI + $MI + $SI
ConvertTo-Html -Head $Head -Body $Body | Out-File C:\Classfiles\ServerReport.html

Invoke-Item C:\Classfiles\ServerReport.html


# Step 4: Save the report generating code from the previous step as C:\Classfiles\ServerReport.ps1 and verify that it works.
# A version of the file is saved as C:\Classfiles\Labfiles\Mod03\ServerReport.ps1
C:\Classfiles\Labfiles\Mod03\ServerReport.ps1


# Step 5: Add the report as an option to the C:\Classfiles\ServerResources.ps1 controller script.
# Save the new controller script as C:\Classfiles\ServerResourcesandReports.ps1
# A sample version of this script is saved as C:\Classfiles\Labfiles\Mod03\ServerResourcesandReports.ps1
C:\Classfiles\Labfiles\Mod03\ServerResourcesandReports.ps1
