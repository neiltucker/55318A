﻿## Lesson 1: Understanding controller scripts
## Test tool scripts that will be used for a controller script
## The controller script to be created in a later lesson will manage three tool scripts: Get-DiskInfo, Get-MemoryInfo and Get-SQLInfo

# Step 1: Test the Get-DiskInfo function.
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $disks = Get-CimInstance -ComputerName $computer -ClassName Win32_LogicalDisk -Filter "DriveType=3"
            foreach ($disk in $disks) {
                $properties = @{'ComputerName' = $computer;
                                'DriveLetter' = $disk.deviceid;
                                'DriveType' = $disk.drivetype;
                                'FreeSpace / GB' = [math]::round($disk.freespace/1GB,2);
                                'Size / GB' = [math]::round($disk.size/1GB,2) }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo 


# Step 2: Test the Get-MemoryInfo function.
function Get-MemoryInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $css = Get-CimInstance -ComputerName $computer -ClassName Win32_ComputerSystem
            foreach ($cs in $css) {
                $properties = @{'ComputerName' = $computer;
                                'Domain' = $cs.domain;
                                'RAM / GB' = [math]::round($cs.totalphysicalmemory/1GB,2);
                                'Model' = $cs.model;
                                'Manufacturer' = $cs.manufacturer }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo 


# Step 3: Test the Get-SQLInfo function.
#Requires -Module SqlServer
function Get-SQLInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerInstance')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $instance = Get-SqlInstance -ServerInstance $computer
            foreach ($i in $instance) {
                $properties = @{'InstanceName' = $computer;
                                'Version' = $i.version;
                                'ProductLevel' = $i.productlevel;
                                'HostPlatform' = $i.hostplatform;
                                'HostDistribution' = $i.hostdistribution }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-SQLInfo 


# Step 4: Save all three functions as the new LabTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools folder
New-Item -Path $UserModuleFolder"\LabTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools file
Copy-Item -Path C:\Classfiles\Labfiles\Mod03\LabToolsv1.ps1 -Destination $UserModuleFolder"\LabTools\LabTools.psm1"

# Test the updated DemoTools module script.  
Remove-Module LabTools
Remove-Item -Path Function:\Get-DiskInfo
Remove-Item -Path Function:\Get-MemoryInfo
Remove-Item -Path Function:\Get-SQLInfo
Get-Command -Module LabTools
Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-SQLInfo 
