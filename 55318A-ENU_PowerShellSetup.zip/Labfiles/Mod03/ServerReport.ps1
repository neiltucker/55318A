﻿# Create Server Resources Report

$DI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-DiskInfo | Where-Object {$_.DriveType -eq '3'} | `
 ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Disk Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$MI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-MemoryInfo | ` 
 ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Computer System Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$SI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-SQLInfo | ` 
 ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>SQL Server Instance Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"

$Title = "<title>Server Resources Report</title>"
$Header = "<h1><b>Server Resources:</b></h1>"
$Head = $Title + $Header
$Body = $DI + $MI + $SI
ConvertTo-Html -Head $Head -Body $Body | Out-File C:\Classfiles\ServerReport.html

Invoke-Item C:\Classfiles\ServerReport.html
Write-Host "Report saved as: C:\Classfiles\ServerReport.html"