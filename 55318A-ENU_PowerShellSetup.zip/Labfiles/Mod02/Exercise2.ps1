﻿## Lesson 1: Using REST API in PowerShell
## Using REST API to manage IIS websites

# Step 1: Verify IIS is installed on the server.
$WebServer = Get-WindowsFeature "Web-Server"
if(!$WebServer.Installed){Install-WindowsFeature $WebServer -IncludeManagementTools -IncludeAllSubFeature}

# Step 2: Query IIS website API
$APIUrl = "http://" + [System.Net.Dns]::GetHostByName($env:computerName).hostname
Invoke-WebRequest -Uri $APIUrl -UseBasicParsing
$IISAPI = Invoke-WebRequest -Uri $APIUrl -UseBasicParsing
$IISAPI.Content


# Step 3: Perform this step only if Internet access is available on the system.  Query PowerShell Blog.
# Note: This step may also be done in a Microsoft Azure Cloud Shell console if an Azure subscription was provided with the class.
$PowerShellBlogs = "https://blogs.msdn.microsoft.com/powershell/feed/"
Invoke-RestMethod -Uri $PowerShellBlogs
$BlogUrl = Invoke-RestMethod -Uri $PowerShellBlogs
$BlogUrl | Select-Object Title, Link 
$BlogUrl | Select-Object Title, Link | ConvertTo-Json -OutVariable BlogJson
$BlogJson
$BlogJson | Out-File output.json
$BlogUrl | Select-Object Title, Link | ConvertTo-CSV -NoTypeInformation -OutVariable BlogCSV
$BlogCSV
$BlogCSV | Out-File output.csv
$BlogUrl | Select-Object Title, Link | ConvertTo-XML -OutVariable BlogXML 
$BlogXML.innerXml 
$BlogXML.innerXml | Out-File output.xml


# Step 4: Use an IIS REST API to host and capture data from WMI
# Start an HTTP listener on port 8888
$listener = New-Object System.Net.HTTPListener
$listener.Prefixes.Add('http://+:8888/') 
$listener.Start()

# Run the While loop.  It will continue capturing data for the HTTP listener until a GET "/stop" message is received.
While ($True) {
    # Get request and post response
    $context = $listener.GetContext() 
    $request = $context.Request
    $response = $context.Response
   
    # Stop if GET request includes "/stop"
    If ($request.Url -match "/stop") { 
        $listener.Stop()
        Break 
    } Else {
        # Get WMI class and computer from URL
        $requestvars = ([String]$request.Url).split("/")      
        $result = Get-WMIObject $requestvars[4] -ComputerName $requestvars[5]
        
        # Convert and save data
        $message = $result | ConvertTo-Json
        $message | Out-File -FilePath C:\Classfiles\output.json
        $response.ContentType = 'application/json'
        [byte[]]$buffer = [System.Text.Encoding]::UTF8.GetBytes($message)
        $response.ContentLength64 = $buffer.length
        $output = $response.OutputStream
        $output.Write($buffer, 0, $buffer.length)
        $output.Close()
   }
}
 
# Run this code in a separate Administrator: PowerShell Console
# URL Request for data from wmi
$WMIClass = "Win32_LogicalDisk"
$ComputerName = $env:COMPUTERNAME
$requestURL = "http://localhost:8888/wmi/" + $WMIClass + "/" + $ComputerName
# Note: The URL can also be run directly from a browser
Invoke-WebRequest -Uri $requestURL -UseBasicParsing

# When finished testing, stop the listender by running this code in the same Administrator: PowerShell Console as the previous task
$requestURL = "http://localhost:8888/wmi/" + $WMIClass + "/" + $ComputerName + "/stop"
Invoke-WebRequest -Uri $requestURL -UseBasicParsing

# Verify the output in C:\Classfiles\output.json.  It should change each time you modify the $WMIClass variable
Notepad C:\Classfiles\output.json
