﻿# This script configures the Hyper-V Machines used for the 55318 Course.
# Updates to class files can be found on GitHub (https://github.com/neiltucker/55318A). 
# This script will only work on computers that run Hyper-V 3.0 or higher and PowerShell 3.0 or higher.
# The Drive that corresponds to the $VMLOC variable should have at least 100GB of free space available.
# The Drive that corresponds to the $Labfiles variable should have at least 20GB of free space available.
# All the files for the 55318 class should be copied to $Labfiles before running this script.

### Create Variables
# Minimum Memory for VMs
$RAM = 2GB
# Maximum Drive space for servers
$VHDSize = 120GB
# Name of Domain Controller				
$DC1 = "LON-DC1"
# Name of Domain Member Server
$SRV1 = "LON-SRV1"
# Location of all installation files.  Avoid changing.
$Labfiles = "C:\Labfiles.55318"
Set-Location $Labfiles
$SetupFiles = "55318A-ENU_PowerShellSetup.zip"
Expand-Archive $SetupFiles $Labfiles -Force -ErrorAction "SilentlyContinue"
Get-ChildItem $Labfiles -Recurse | UnBlock-File -ErrorAction SilentlyContinue
$DCISO = "C:\Labfiles.55318\WS2022.ISO"		        # Name of DC ISO
$SRVISO = "C:\Labfiles.55318\WS2022.ISO"		# Name of Windows Server ISO
$SQLISO = "C:\Labfiles.55318\SQL2019.ISO"		# Name of SQL Server ISO
# Change to drive where most free space is available
$VMLOC = "C:\HyperV"
$Network1 = "Default Switch"				# If necessary, use existing Hyper-V switch for Internet access
$Network2 = "55318InternalNetwork"			# Internal Network Switch for Contoso.com domain traffic
$VHDMP = "S:"
$StartTime = Get-Date -Format "yyyy-MM-ddTHH:mm:ss"	# Time VM setup process started

### Install PowerShell Modules
If ((Get-PSRepository -Name PSGallery).InstallationPolicy = "Trusted") {Write-Output "PSGallery is already a trusted repository"} Else {Set-PSRepository -Name PSGallery -InstallationPolicy Trusted}
If (Get-PackageProvider -Name NuGet) {Write-Output "NuGet PackageProvider already installed."} Else {Install-PackageProvider -Name "NuGet" -Force -Confirm:$False}
If (Get-Module -ListAvailable -Name PowerShellGet) {Write-Output "PowerShellGet module already installed"} Else {Find-Module PowerShellGet -IncludeDependencies | Install-Module -Force}
If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -AllowClobber -Force ; Import-Module -Name SQLServer}
Remove-Item -Recurse -Force $Labfiles\SqlServerModule -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\SqlServerModule -Force
Save-Module -Name SqlServer -Path $Labfiles\SqlServerModule\
Remove-Item -Recurse -Force $Labfiles\PowerShellGet -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\PowerShellGet -Force
Save-Module -Name PowerShellGet -Path $Labfiles\PowerShellGet
# Archive Module Folders
Compress-Archive -Path $WorkFolder"SQLServer",$WorkFolder"PackageManagement",$WorkFolder"PowerShellGet",$WorkFolder"NuGet" -DestinationPath $WorkFolder"Modules.zip" -Force

### Load HyperV Module
Write-Output "Load HyperV Module"
Get-ChildItem $PSHome\Modules -Recurse | UnBlock-File -ErrorAction SilentlyContinue
$HyperV = Get-Module Hyper-V
if ($HyperV -eq $Null) {Import-Module Hyper-V -ErrorAction SilentlyContinue}

### Download PowerShell version 7
Write-Output "Download PowerShell version 7"
Invoke-WebRequest -Uri https://github.com/PowerShell/PowerShell/releases/download/v7.2.4/PowerShell-7.2.4-win-x64.msi -OutFile $Labfiles\PowerShell-7.2.4-win-x64.msi

### Download AdventureWorks & AdventureWorksDW backup files
Write-Output "Download AdventureWorks & AdventureWorksDW backup files"
& $Labfiles\adventureworks_download.ps1
& $Labfiles\adventureworksdw_download.ps1

### Copy Windows Server & SQL Server files
# Copy Windows Server 2022 Files Needed to Configure Windows Features on VM
Write-Output "     *****     Copy Windows Server 2022 Files     *****"
$TPDCISO = Test-Path $DCISO ; If ($TPDCISO -eq $False){cls ; "The Windows Server 2022 Files could not be found at $DCISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
& $Labfiles\ws2022_Files.ps1
# Copy SQL Server 2019 Files
Write-Output "     *****     Copy SQL Server 2019 Setup Files    *****"
$TPSQLISO = Test-Path $SQLISO ; If ($TPSQLISO -eq $False){cls ; "The SQL Server 2019 Files could not be found at $SQLISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
& $Labfiles\SQL2019_Files.ps1

### Verify Setup Folders are named properly
$TPWS = Test-Path $Labfiles\Sources\SXS ; If ($TPWS -eq $False){cls ; "The Windows Server 2022 Files are not in $Labfiles\Sources\SXS.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

$VerifySQL = 0
Do {
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2019 ; If ($TPSQL -eq $True) {$VerifySQL = 4} `
Else {$VerifySQL++ ; echo "Trying to Rename SQL Server Setup Folder" ; Start-Sleep 5 ; `
Rename-Item $Labfiles\SQLServer\CDROM1 $Labfiles\SQLServer\SQL2019 -PassThru -Force -ErrorAction SilentlyContinue ;}
}
While ($VerifySQL -le 3)
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2019 ; If ($TPSQL -eq $False){cls ; "The SQL Server Files are not in $Labfiles\SQLServer\SQL2019.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

### Verify that the VMs do not already exist.
Write-Output "Verify that the VMs do not already exist"
$VMDC1 = Get-VM $DC1 -ErrorAction SilentlyContinue; If ($VMDC1) {echo "***   The $DC1 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$TPLabfiles = Test-Path $Labfiles ; If ($TPLabfiles -eq $False){cls ; "The $Labfiles folder does not exist." ; "Please verify the location of the classroom setup files." ; Start-Sleep 15 ; exit}
$TPDC1HD1 = Test-Path $VMLOC\$DC1.vhdx ; If ($TPDC1HD1 -eq $True){cls ; "The " + $DC1 + " VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPDC1HD2 = Test-Path $VMLOC\Labfiles_$DC1.vhdx ; If ($TPDC1HD2 -eq $True){cls ; "The Labfiles_$DC1 VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
Remove-VMSwitch $Network2 -Force -ErrorAction SilentlyContinue
MD $VMLOC -ErrorAction SilentlyContinue

### Create VMs and get MAC Addresses for Network Adapters
Write-Output "Configure VMs 55318-LON-DC1 & 55318-LON-SRV1"
$DC1 | New-VM -Path $VMLOC -SwitchName $Network1
$SRV1 | New-VM -Path $VMLOC -SwitchName $Network1
New-VMSwitch $Network2 -SwitchType Internal
Get-VM $DC1, $SRV1 | Add-VMNetworkAdapter -SwitchName $Network2
Get-VM $DC1, $SRV1 | Set-VMProcessor -Count 4 -Reserve 25 -Maximum 80
Get-VM $DC1, $SRV1 | Set-VMMemory -DynamicMemoryEnabled $true -MinimumBytes $RAM -StartupBytes $RAM -MaximumBytes 6GB
Get-VM $DC1, $SRV1 | Start-VM
Start-Sleep 10
$DC1MAC = Get-VMNetWorkAdapter $DC1 | Where {$_.SwitchName -eq $Network2} | Select MacAddress | ConvertTo-CSV; $DC1MAC[2] | Out-File $Labfiles\$DC1.txt
$DC1MAC1 = Get-Content $Labfiles\$DC1.txt
$SRV1MAC = Get-VMNetWorkAdapter $SRV1 | Where {$_.SwitchName -eq $Network2} | Select MacAddress | ConvertTo-CSV; $SRV1MAC[2] | Out-File $Labfiles\$SRV1.txt
$SRV1MAC1 = Get-Content $Labfiles\$SRV1.txt
Get-VM $DC1, $SRV1 | Stop-VM -Turnoff -Force

### Create VHDX Drives
Write-Output "     *****     Create VHDX drives     *****" 
& $Labfiles\labfiles.ps1

### Configure Contoso.com domain controller (55318-LON-DC1)
# Mount Drives and Controllers
New-VHD -Path $VMLOC\$DC1.vhdx -size $VHDSize
Add-VMHardDiskDrive -VMName $DC1 -ControllerNumber 0 -ControllerType IDE -Path $VMLOC\$DC1.VHDX
Add-VMHardDiskDrive -VMName $DC1 -Controllernumber 0 -controllertype IDE -Path $VMLOC\Labfiles_$DC1.VHDX
Remove-VMDVDDrive -ControllerNumber 1 -ControllerLocation 0 -VMName $DC1 -ErrorAction SilentlyContinue
Add-VMDVDDrive -ControllerNumber 1 -ControllerLocation 0 -VMName $DC1 -Path $DCISO 
Set-VMFloppyDiskDrive $DC1 $Labfiles\dc1install.vfd
# Configure DC
Start-VM $DC1
Get-Date
Write-Output "Automated setup of virtual machine 55318-LON-DC1 is now starting.  Progress can be checked in Hyper-V Manager.  The setup should finish in less than one hour."
Write-Output "The setup of 55318-LON-SRV1 will start in 15 minutes."
Start-Sleep 900

### Configure Contoso.com domain member server (55318-LON-SRV1)
# Mount Drives and Controllers
New-VHD -Path $VMLOC\$SRV1.vhdx -Size $VHDSize
Add-VMHardDiskDrive -VMName $SRV1 -ControllerNumber 0 -ControllerType IDE -Path $VMLOC\$SRV1.VHDX
Add-VMHardDiskDrive -VMName $SRV1 -controllernumber 0 -ControllerType IDE -Path $VMLOC\Labfiles_$SRV1.VHDX
Remove-VMDVDDrive -Controllernumber 1 -ControllerLocation 0 -VMName $SRV1 -ErrorAction SilentlyContinue
Add-VMDVDDrive -Controllernumber 1 -ControllerLocation 0 -VMName $SRV1 -Path $SRVISO 
Set-VMFloppyDiskDrive $SRV1 $Labfiles\srv1install.vfd
# Configure 
Start-VM $SRV1
Get-Date
Write-Output "Automated setup of virtual machine 55318-LON-SRV1 is now starting.  Progress can be checked in Hyper-V Manager.  The setup should finish in less than one hour."

### Configure Output File
$et = Get-Date
$EndTime = $et.ToString("yyyy-MM-ddTHH:mm:ss")
$outputfile = "55318HyperVSetup" + $et.ToString("yyyyMMddHHmmss") + ".txt" 
Write-Output "Start Time:    $StartTime" > $Labfiles"\"$outputfile
Write-Output "End Time:      $EndTime" >> $Labfiles"\"$outputfile
Write-Output "VM Name:       $DC1" >> $Labfiles"\"$outputfile
Write-Output "Contoso MAC:   $DC1MAC1" >> $Labfiles"\"$outputfile
Get-Content $Labfiles"\"$outputfile

