﻿# Use the function to read BIOS information, create an Event Log source ("BIOSInfo7") and write error information to Application Log. 
# Fix all errors so the BIOS information is displayed and Event ID 3001 messages are properly written to the Application log.

$MyBiosInfo = "BiosInfo7"
function Get-BIOSInfo7 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    New-EventLog –LogName Application –Source $MyBiosInfo -ErrorAction SilentlyContinue
    Try {
      Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $_.PSComputerName BIOS Serial Name: $_.SerialNumber" -EA Stop
      }
    Catch {
      Write-Debug "There was an error writing BIOS information to the Event Log."
      Write-EventLog -LogName Application -Source $MyBiosInfo -EntryType Error -EventID 1000 -Message $_
          }
    Finally {
      Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName
      }
}

Get-BIOSInfo7 -ComputerName LON-DC1, LON-SRV1

Get-EventLog -LogName Application -Source "BIOSInfo7" -Newest 2 | fl
