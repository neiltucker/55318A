﻿# Test using an interactive session in PowerShell ISE using PowerShell 7
Enter-PSSession -ComputerName $env:COMPUTERNAME -ConfigurationName powershell.7
$PSVersionTable.PSVersion

# Write error information to the application Event Log
New-EventLog –LogName Application –Source “BIOSInfo4”
function Get-BIOSInfo4 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $FilePath ="C:\Classfiles\Mod04Lesson2Step3.log"
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Try {Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop}
    Catch {Write-Output "There was an error writing BIOS information to the Event Log."
           Write-EventLog -LogName Application -Source "BIOSInfo4" -EntryType Error -EventID 1000 -Message $_
          }
    Finally {$BI}
}

Get-BIOSInfo4
# Check the Application Event Log for errors that match your application "Source"
Get-EventLog -LogName Application -Source "BIOSInfo4" 

