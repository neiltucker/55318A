﻿Get-CimInstance -ClassName Win32_DiskDrive
Get-CimInstance -ClassName Win32_LogicalDisk 
Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName 'lon-srv1','lon-dc1'


# Step 2: Use a basic parameter block to specify an optional parameter for -ComputerName
Param(
    [array]$ComputerName = @('lon-srv1','lon-dc1')
)
Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName


# Step 3: Create the function and add CmdletBinding capabilities
function Get-DiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Provide the computer name')]
        [Alias('Server')]
        [ValidateNotNullOrEmpty()]
        $ComputerName = $env:ComputerName
    )
    Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName 
}

Get-DiskInfo -Server lon-srv1, lon-dc1

# Step 4: Test the previous function to make sure it returns disk information for multiple computers 
Get-DiskInfo
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-DiskInfo -ComputerName $_.ComputerName}