﻿$os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName
$cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $ComputerName 

$properties = @{'ComputerName'=$ComputerName; 
    'OSVersion' = $os.Version;
    'RAM' = $cs.TotalPhysicalMemory; 
    'Manufacturer' = $cs.Manufacturer; 
    'Model' = $cs.Model} 

$properties.GetType()
Write-Output $properties

$obj = New-Object –TypeName PSObject –Property $properties 
$obj.GetType()
write-output $obj

