﻿Stop-Process -Id 1000000 -ErrorAction Stop ; Write-Output "Output on same line."



