--  Change location & growth settings for MSDB database
Use Master
go
Alter Database MSDB Modify File (NAME=MSDBData, FILEGROWTH=100MB, MAXSIZE=10000MB, FILENAME='E:\DATA\msdbdata.mdf')
go
Alter Database MSDB Modify File (NAME=MSDBLog, FILEGROWTH=25MB, MAXSIZE=2500MB, FILENAME='F:\LOG\msdblog.ldf')
go
