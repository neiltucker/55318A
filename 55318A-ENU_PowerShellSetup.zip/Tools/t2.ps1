﻿Stop-Process -Id 1000000 -ErrorAction Continue ; Write-Output "Output on same line."



