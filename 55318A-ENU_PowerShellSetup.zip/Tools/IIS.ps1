﻿
# Start an HTTP listener on port 8888
$listener = New-Object System.Net.HTTPListener
$listener.Prefixes.Add('http://+:8888/') 
$listener.Start()

# Run until GET request includes /stop
While ($True) {
    # Get request and post response
    $context = $listener.GetContext() 
    $request = $context.Request
    $response = $context.Response
   
    # Stop if GET request includes "/stop"
    If ($request.Url -match "/stop") { 
        $listener.Stop()
        Break 
    } Else {
        # Get WMI class and computer from URL
        $requestvars = ([String]$request.Url).split("/")      
        $result = Get-WMIObject $requestvars[4] -ComputerName $requestvars[5]
        
        # Convert and save data
        $message = $result | ConvertTo-Json
        $message | Out-File -FilePath C:\Classfiles\output.json
        $response.ContentType = 'application/json'
        [byte[]]$buffer = [System.Text.Encoding]::UTF8.GetBytes($message)
        $response.ContentLength64 = $buffer.length
        $output = $response.OutputStream
        $output.Write($buffer, 0, $buffer.length)
        $output.Close()
   }
}
 
# Run this code in a separate Administrator: PowerShell Console
# URL Request for data from wmi
$WMIClass = "Win32_LogicalDisk"
$ComputerName = $env:COMPUTERNAME
$requestURL = "http://localhost:8888/wmi/" + $WMIClass + "/" + $ComputerName
# Note: The URL can also be run directly from a browser
Invoke-WebRequest -Uri $requestURL -UseBasicParsing

# When finished testing, stop the listender
$requestURL = "http://localhost:8888/wmi/" + $WMIClass + "/" + $ComputerName + "/stop"
Invoke-WebRequest -Uri $requestURL -UseBasicParsing


 