﻿Backup-Gpo -Name "Default Domain Policy" -Path C:\Classfiles -Comment "Maintain PowerShell Execution Policy Settings"

Restore-GPO -Name "Default Domain Policy" -Path C:\Classfiles\Tools