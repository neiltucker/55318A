﻿$Continue = $True
While ($Continue) {
    Write-Host "1. Display disk information"
    Write-Host "2. Display RAM information"
    Write-Host "3. Display operating system version"
    Write-Host "X. Exit the menu"

    $choice = Read-Host "Enter your choice"
    Switch ($choice) {
        1 { Get-DiskInfo -ComputerName $env:COMPUTERNAME }
        2 { Get-MemoryInfo -ComputerName $env:COMPUTERNAME }
        3 { Get-SQLInfo -ComputerName $env:COMPUTERNAME}
        'X' { $Continue = $False }
        default { Write-Host "Invalid choice.  Select a menu option" -ForegroundColor red
        }
    }
}
