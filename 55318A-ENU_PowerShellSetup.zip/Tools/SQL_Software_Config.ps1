[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
$Server = new-object ('Microsoft.SQLServer.Management.Smo.Server') MIA-SQL
$Server.Configuration.MinServerMemory.ConfigValue = 1024
$Server.Configuration.MaxServerMemory.ConfigValue = 2048
$Server.Configuration.Alter()
$Server.Settings.LoginMode = "Mixed"
$Server.Settings.Alter()
Invoke-SQLCMD "Alter Server Configuration SET PROCESS AFFINITY CPU = 0 TO 1"
Invoke-SQLCMD -InputFile "C:\Classfiles\Backup_SystemDB.sql"
Restart-Service MSSQLServer -Force