﻿# Use the function to read BIOS information, create an Event Log source ("BIOSInfo7") and write error information to Application Log. 
# Fix all errors so the BIOS information is displayed and Event ID 3001 messages are properly written to the Application log.

function Get-BIOSInfo7 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    Try {
      New-EventLog –LogName Application –Source “BIOSInfo7” -ErrorAction SilentlyContinue
      foreach ($computer in $ComputerName) {
      $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $computer
      $Message = "Computer: " + $computer + " BIOS_Serial_Name: " + $BI.SerialNumber
      Write-EventLog -Logname Application -Source "BIOSInfo7" -EventID 3001 -Message $Message -EA Stop
      }
      }
    Catch {
      Write-Output "There was an error writing BIOS information to the Event Log."
      Write-EventLog -LogName Application -Source "BIOSInfo7" -EntryType Error -EventID 1000 -Message $_
          }
    Finally {
      $BI
      }
}

Get-BIOSInfo7 -ComputerName LON-DC1, LON-SRV1

Get-EventLog -LogName Application -Source "BIOSInfo7" -Newest 2 | FL
