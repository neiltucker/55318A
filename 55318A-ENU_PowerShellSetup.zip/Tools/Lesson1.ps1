## Lesson 1: Converting a command into a function
## Create a function to display computer hardware information for a specified computer

# Step 1: Test the command and choose option(s) to be parameterized.
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName localhost
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $env:computername


# Step 2: Use a parameter block to specify an optional parameter for computer name
$ComputerName = 'localhost'

Param(
    [string]$ComputerName = 'localhost'
)
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName


# Step 3: Create the function and add CmdletBinding capabilities
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]$ComputerName = $env:COMPUTERNAME
    )
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
}

# Step 4: Test the previous function definition by executing it in PowerShell ISE 
Get-CorpCompSysInfo
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-CorpCompSysInfo -ComputerName $_.ComputerName}

# Step 5: 







