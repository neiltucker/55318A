Invoke-SQLCMD -InputFile D:\Labfiles\Modify_TempDB.sql
Stop-Service MSSQLSERVER -Force
cd D:\MSSQLSERVER\MSSQL11.MSSQLSERVER\MSSQL\DATA
Remove-Item Tempdb.mdf; Remove-Item Templog.ldf 
Start-Service MSSQLSERVER 
Start-Service SQLSERVERAGENT

