﻿Import-Module ActiveDirectory
Import-Module GroupPolicy
$Contoso = Get-ADDomainController -Discover -Service PrimaryDC
Get-GPOReport -All -Domain contoso.com -Server $Contoso -ReportType HTML -Path C:\Classfiles\Tools\GPOReportsAll.html

