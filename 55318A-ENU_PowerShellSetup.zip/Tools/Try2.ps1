﻿$CN = 'Invalid-SRV1'
Try { 
$Computer = Get-CimInstance Win32_ComputerSystem –ComputerName $CN –EA Stop 
} 
Catch { 
Write-Warning "Catch: Unable to connect to: $CN" ; Write-Output $_ 
} 
Finally { 
Write-Output "Finally: Try/Catch complete." 
}
