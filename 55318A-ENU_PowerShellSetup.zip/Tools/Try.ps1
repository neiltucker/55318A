﻿$CN = 'LON-SRV002'
Try { 
Write-Output "Try 1"
$Computer = Get-CimInstance Win32_ComputerSystem –ComputerName $CN –EA Stop 
Write-Output "Try 2"
} 
Catch {
Write-Output "Catch 1"
Write-Warning "Unable to connect to $CN" 
Write-Output "Catch 2"
Write-Output ":::" $_
} 
Finally { 
 Write-Output "Finally 1"
 Write-Output "Finally: Try/Catch complete." 
 Write-Output "Finally 2"
 Write-Output ":::" $_
 } 
