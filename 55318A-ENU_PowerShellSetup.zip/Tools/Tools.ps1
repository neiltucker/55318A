﻿# Copy all *.ps1 scripts in C:\Classfiles to the C:\Tmp\Tools folder.  Preverse the folder and file heirarchy of the *.ps1 files.
$SourceFolder = "C:\Classfiles"
$DestinationFolder = "C:\Tmp\Tools"
New-Item -ItemType Directory -Path $DestinationFolder
Get-ChildItem -LiteralPath $SourceFolder -Name -Recurse -Include *.ps1 | `
Copy-Item -LiteralPath { Join-Path $SourceFolder $_ } -Destination { New-Item -Type Directory -Force (Split-Path (Join-Path $DestinationFolder $_)) } 
