﻿Workflow Set-PDFPrinter 
{
Enable-WindowsOptionalFeature -Online -FeatureName "Printing-PrintToPDFServices-Features"
Invoke-CimMethod -Query 'Select * from Win32_Printer where name like "Microsoft Print to PDF%"' -MethodName SetDefaultPrinter
}

