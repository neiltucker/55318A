﻿function ConvertFrom-Xml($XML) 
{
  Foreach ($Object in ($XML.Objects.Object)) {
    $PSObject = New-Object PSObject
    Foreach ($Property in ($Object.Property)) {
        $PSObject | Add-Member NoteProperty $Property.Name $Property.InnerText
    }
    $PSObject
  }
}

ConvertFrom-Xml $STxml