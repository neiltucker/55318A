### Install SMTP and Telnet

$SMTP = get-WindowsFeature "smtp-server"
$TELNET = get-WindowsFeature "telnet-client"
if(!$SMTP.Installed){add-WindowsFeature $SMTP}
if(!$TELNET.Installed){add-WindowsFeature $TELNET}
Set-Service -Name "SMTPSVC" -StartupType Automatic
Start-Service -Name "SMTPSVC"

