﻿Workflow Start-SMTP { 
 [CmdletBinding()] 
 Param 
 ( 
 [Parameter(Mandatory=$True)]
 [String[]]$ComputerName
 )
 foreach ($computer in $ComputerName) {
   Get-Service -PSComputerName $computer -Name "SMTPSVC" | Start-Service
   if ((get-service -name "smtpsvc").Status -eq "Running") {Write-Output "SMTP Service is running on: $computer" }
   else {Write-Output "SMTP Service is not running on: $computer" }
  }
} 
