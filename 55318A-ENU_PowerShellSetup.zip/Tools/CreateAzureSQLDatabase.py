# Create a Resource Group and Storage Account in Microsoft Azure
# Resource Groups are used to store and organize resources in Azure.
# Storage Accounts are used to store & share your data & files in different formats.
# Run this code from a python session on the Azure Cloud Shell.
# After the resource group and storage account are created, verify their configuration in the Azure Portal (http://portal.azure.com)
# Continue with the creation of your other resources then delete the resource group once you are finished with them.

'''
# importlib package must be installed for this script to work
# pip install importlib
pip install --user azure-mgmt azure-common azure-storage azure-storage-common azure-cli azure-cli-core pyodbc
pip list
python
'''

### This looping operation will install the modules not already configured.
import importlib, os, sys, datetime
packages = ['azure', 'azure.mgmt', 'azure.common', 'azure.storage', 'azure.storage.common', 'azure.storage.blob', 'azure.storage.file', 'azure.cli', 'azure.cli.core', 'pyodbc']
for package in packages:
  try:
    module = importlib.__import__(package)
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    os.system(cmd)
    module = importlib.__import__(package)

# These modules are used for authenticating to Azure, using resources and managing storage.  
# Install them if they are not already on the system:
import datetime, os, requests, pyodbc, csv
from azure.common.client_factory import get_client_from_cli_profile
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.storage.common import CloudStorageAccount
from azure.storage.file import FileService
from azure.storage.blob import PublicAccess
from azure.mgmt.sql import SqlManagementClient

# Configure Clients for Managing Resources
resource_client = get_client_from_cli_profile(ResourceManagementClient)
storage_client = get_client_from_cli_profile(StorageManagementClient)
sql_client = get_client_from_cli_profile(SqlManagementClient)

# Configure Variables
externalip = requests.get('https://ipapi.co/ip/').text
homedirectory = os.path.expanduser("~")
workfolder = os.path.normpath(homedirectory + '/clouddrive/labfiles.55318a/')
os.chdir(workfolder)
nameprefix = 'np' + (datetime.datetime.now()).strftime('%H%M%S')     # replace 'np' with your initials
resource_group_name = nameprefix + 'rg'
storage_account_name = nameprefix + 'sa'
location = 'eastus'
sharename = '55318'
filename = 'input.csv'
sql_server_name = nameprefix + 'sql'
server_fqdn = sql_server_name + '.database.windows.net'
sql_db_name = nameprefix + 'db'
username = 'sqllogin1'
password = 'Password:123'


def main():
    # Create the Resource Group and Storage Account.  Use Azure Portal to examine their properties before deleting them.
    global resource_group, storage_account
    resource_group_params = {'location':location}
    global resource_group, storage_account
    resource_group = resource_client.resource_groups.create_or_update(resource_group_name, resource_group_params)
    storage_account = storage_client.storage_accounts.create(resource_group_name, storage_account_name, {'location':location,'kind':'storage','sku':{'name':'standard_ragrs'}})
    storage_account.wait()


main()

def shares(sharename):
    # Create Container and Share
    global storage_account_key, blob_service, blob_share, file_service, file_share
    sak = storage_client.storage_accounts.list_keys(resource_group_name, storage_account_name)
    storage_account_key = sak.keys[0].value
    cloudstorage_client =  CloudStorageAccount(storage_account_name,storage_account_key)
    blob_service = cloudstorage_client.create_block_blob_service()
    blob_share = blob_service.create_container(sharename,public_access=PublicAccess.Container)
    file_service = FileService(account_name=storage_account_name, account_key=storage_account_key)
    file_share = file_service.create_share(sharename)


shares(sharename)


# Copy Setup Files to Container and Share
blob_service.create_blob_from_path(sharename,filename,filename,)
file_service.create_file_from_path(sharename,'',filename,filename,)


def create_sql_server(sql_server_name):
    # Create Azure SQL Server
    global sql_server
    sql_server = sql_client.servers.create_or_update(resource_group_name,sql_server_name,
        {
            'location': location,
            'version': '12.0',
            'administrator_login': username, 
            'administrator_login_password': password
        }
    )
    sql_server.wait()


create_sql_server(sql_server_name)


def create_db(sql_db_name):
    # Create Azure SQL Database
    global sql_db
    sql_db = sql_client.databases.create_or_update(resource_group_name,sql_server_name,sql_db_name,
        {
            'location': location,
            'collation': 'SQL_Latin1_General_CP1_CI_AS',
            'create_mode': 'default',
            'requested_service_objective_name': 'Basic'
        }
    )
    sql_db.wait()


create_db(sql_db_name)

def configure_firewall():
    # Create Firewall Rules
    global allow_all_azure_ips, allow_external_ip
    allow_all_azure_ips = sql_client.firewall_rules.create_or_update(resource_group_name,sql_server_name,
        "AllowAllWindowsAzureIPs","0.0.0.0", "0.0.0.0"
    )
    allow_external_ip = sql_client.firewall_rules.create_or_update(resource_group_name,sql_server_name,
        "ExternalIP1",externalip,externalip
    )


configure_firewall()

# Create Table
driver = '{ODBC Driver 17 for SQL Server}'
connection = pyodbc.connect('DRIVER='+driver+';SERVER='+server_fqdn+';PORT=1433;DATABASE='+sql_db_name+';UID='+username+';PWD='+ password)
cursor = connection.cursor()
cursor.execute("CREATE TABLE [dbo].[Employees] ([ID] [nvarchar](50),[LastName] [nvarchar](50),[FirstName] [nvarchar](50),[HireDate] [nvarchar](50),[HireTime] [nvarchar](50))") 
cursor.commit()

# Create List from Input File
with open('input.csv', 'r') as employees:
    next(employees)
    reader = csv.reader(employees)
    employees_list = list(reader)

# Import CSV to Table using List
sql = "INSERT INTO [Employees] (ID,LastName,FirstName,HireDate,HireTime) VALUES (?,?,?,?,?)"
cursor.executemany(sql, employees_list)
cursor.commit()


# Import CSV to Table using Looping Operation
# This method is commented out because of its poor performance.  It is only here as an example.
# Use only 1,000 rows from your input file if you intend on trying this method.
"""
with open ('small.csv', 'r') as employees:
    records = csv.reader(employees)
    columns = next(records) 
    insert = 'insert into Employees({0}) values ({1})'
    query = insert.format(','.join(columns), ','.join('?' * len(columns)))
    cursor = connection.cursor()
    for record in records:
        cursor.execute(query, record)
    cursor.commit()
"""

# Delete Resource Group.  Deleting a resource group will also deleted all objects in it.
# delete_async_operation = resource_client.resource_groups.delete(resource_group_name)
# delete_async_operation.wait()


