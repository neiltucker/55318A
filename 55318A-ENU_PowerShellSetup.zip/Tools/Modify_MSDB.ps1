Invoke-SQLCMD -InputFile D:\Labfiles\Modify_MSDB.sql
Stop-Service MSSQLSERVER -Force
cd D:\MSSQLSERVER\MSSQL11.MSSQLSERVER\MSSQL\DATA
$TPData = Test-Path E:\Data\MSDBData.mdf; If ($TPData -eq False) {Copy-Item MSDBData.mdf E:\Data} 
$TPLog = Test-Path F:\Log\MSDBDLog.ldf; If ($TPLog -eq False) {Copy-Item MSDBLog.ldf F:\Log}
Start-Service MSSQLSERVER 
Start-Service SQLSERVERAGENT

