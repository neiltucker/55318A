--  Change location & growth settings for TempDB database
Use Master
go
Alter Database TempDB Modify File (NAME=TempDev, FILEGROWTH=100MB, MAXSIZE=10000MB, FILENAME='E:\DATA\tempdb.mdf')
go
Alter Database TempDB Modify File (NAME=TempLog, FILEGROWTH=25MB, MAXSIZE=2500MB, FILENAME='F:\LOG\templog.ldf')
go
