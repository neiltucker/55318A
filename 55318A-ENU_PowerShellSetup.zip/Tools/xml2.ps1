﻿## Lesson 1: Working with XML formatted data
## Reading XML data and creating XML documents

# Step 1: Read 10 records from a SQL Server database table (AdventureWorks2019.Sales.vSalesPerson) and save the records in CSV and XML formatted files.
# Note: You must first restore the AdventureWorks2019 database from a backup using the provided script.
# Note: Make sure the database is not in use before running the script.  If necessary, delete the existing database using SSMS.
C:\Classfiles\AdventureWorks_Install.ps1

$SalesTeam = Read-SqlViewData -ServerInstance $env:ComputerName -DatabaseName "AdventureWorks2019"  -SchemaName "Sales" -ViewName "vSalesPerson" -TopN 10 | `
 Select-Object FirstName,Lastname,PhoneNumber,EmailAddress
$SalesTeam
$SalesTeam | ConvertTo-CSV -NoTypeInformation | Out-File C:\Classfiles\demosalesteam.csv
$SalesTeam | ConvertTo-Xml -As "Stream" -Depth 3 | Out-File C:\Classfiles\demosalesteam.xml
$SalesTeam | Export-Clixml -Path C:\Classfiles\demosalesteam2.xml
Import-Clixml -Path C:\Classfiles\demosalesteam2.xml | Select LastName,FirstName

Get-Content C:\Classfiles\demosalesteam2.xml


# Step 2: Read data from the XML document
Get-Content C:\Classfiles\demosalesteam.xml 
Select-Xml -Path C:\Classfiles\demosalesteam.xml -Xpath "/Objects/Object/Property" | Select-Object -ExpandProperty Node
Select-Xml -Path C:\Classfiles\demosalesteam.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node} 
Select-Xml -Path C:\Classfiles\demosalesteam.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.name}
Select-Xml -Path C:\Classfiles\demosalesteam.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.InnerXml}
Select-Xml -Path C:\Classfiles\demosalesteam.xml -Xpath "/Objects/Object/Property" | Foreach-Object {$_.node.InnerText}


# Step 3: Convert the XML file to an XMLDocument object and query records in the object 
[xml]$STxml = Get-Content C:\Classfiles\demosalesteam.xml 
$STxml.GetType()
$STxml
$STxml.Objects.Object
$STxml.Objects.Object | Select -ExpandProperty Property 
$STxml.Objects.Object.ChildNodes | Where {$_.FirstName -eq "David"}



# Step 4: Modify the XML document object
$STxml.Objects.Object.Property.SelectNodes("PhoneNumber")
$STxml.Objects.Object.Property.RemoveChild($PhoneNumber)

$STxml.Objects.Object.Property.RemoveAttribute("PhoneNumber")
