﻿Read-SqlTableData -ServerInstance 'LON-SRV1' -DatabaseName "AdventureWorks2019"  -SchemaName "Person" -TableName "Person" -TopN 3

Read-SqlViewData -ServerInstance 'LON-SRV1' -DatabaseName "AdventureWorks2019"  -SchemaName "Sales" -ViewName "vSalesPerson" -TopN 10 
$SalesPerson = Read-SqlViewData -ServerInstance 'LON-SRV1' -DatabaseName "AdventureWorks2019"  -SchemaName "Sales" -ViewName "vSalesPerson" -TopN 2 
$SalesPerson | Select-Object FirstName,Lastname,PhoneNumber,EmailAddress
$SalesPerson | Select-Object FirstName,Lastname,PhoneNumber,EmailAddress | ConvertTo-Xml -As Stream 
[xml]$SalesPersonXml = $SalesPerson | Select-Object FirstName,Lastname,PhoneNumber,EmailAddress | ConvertTo-Xml -As Stream 

ConvertTo-Xml -As "Document" -InputObject (Get-Process) -Depth 3 | ConvertTo-XML -As 

$SalesPersonXml

ConvertTo-Xml -As "Stream" -InputObject (Get-Process) -Depth 3 | Out-File processes.xml
[xml]$SalesDataXml = Get-Content salesdata.xml
$SalesDataXml.GetType()

