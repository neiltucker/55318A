﻿function Get-CorpDiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $disks = Get-CimInstance -ComputerName $computer -ClassName Win32_LogicalDisk
            foreach ($disk in $disks) {
                $properties = @{'ComputerName' = $computer;
                                'DriveLetter' = $disk.deviceid;
                                'FreeSpace' = $disk.freespace;
                                'DriveType' = $disk.drivetype;
                                'Size' = $disk.size }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}


function Get-CorpMemoryInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $css = Get-CimInstance -ComputerName $computer -ClassName Win32_ComputerSystem
            foreach ($cs in $css) {
                $properties = @{'ComputerName' = $computer;
                                'Domain' = $cs.domain;
                                'RAM' = $cs.totalphysicalmemory;
                                'Model' = $cs.model;
                                'Manufacturer' = $cs.manufacturer }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}


#Requires -Module SqlServer
function Get-CorpSqlInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerInstance')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $instance = Get-SqlInstance -ServerInstance $computer
            foreach ($i in $instance) {
                $properties = @{'InstanceName' = $computer;
                                'Version' = $i.version;
                                'ProductLevel' = $i.productlevel;
                                'HostPlatform' = $i.hostplatform;
                                'HostDistribution' = $i.hostdistribution }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}



