﻿## Lesson 1: Understanding controller scripts
## Test tool scripts that will be used for a controller script
## The controller script to be created in a later lesson will manage three tool scripts: Get-CorpDiskInfo, Get-CorpMemoryInfo and Get-CorpSqlInfo

# Step 1: Test the Get-CorpDiskInfo function.
function Get-CorpDiskInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $disks = Get-CimInstance -ComputerName $computer -ClassName Win32_LogicalDisk -Filter "DriveType=3"
            foreach ($disk in $disks) {
                $properties = @{'ComputerName' = $computer;
                                'DriveLetter' = $disk.deviceid;
                                'FreeSpace' = $disk.freespace;
                                'Size' = $disk.size }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo 


# Step 2: Test the Get-CorpMemoryInfo function.
function Get-CorpMemoryInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $css = Get-CimInstance -ComputerName $computer -ClassName Win32_ComputerSystem
            foreach ($cs in $css) {
                $properties = @{'ComputerName' = $computer;
                                'Domain' = $cs.domain;
                                'RAM' = $cs.totalphysicalmemory;
                                'Model' = $cs.model;
                                'Manufacturer' = $cs.manufacturer }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo 


# Step 3: Test the Get-CorpSqlInfo function.
#Requires -Module SqlServer
function Get-CorpSqlInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerInstance')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $instance = Get-SqlInstance -ServerInstance $computer
            foreach ($i in $instance) {
                $properties = @{'InstanceName' = $computer;
                                'Version' = $i.version;
                                'ProductLevel' = $i.productlevel;
                                'HostPlatform' = $i.hostplatform;
                                'HostDistribution' = $i.hostdistribution }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSqlInfo 


# Step 4: Save all three functions as the new DemoTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools folder
New-Item -Path $UserModuleFolder"\DemoTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools file
Copy-Item -Path C:\Classfiles\Demofiles\Mod03\DemoToolsv1.ps1 -Destination $UserModuleFolder"\DemoTools\DemoTools.psm1"

# Test the updated DemoTools module script.  
Remove-Module DemoTools
Remove-Item -Path Function:\Get-CorpDiskInfo
Remove-Item -Path Function:\Get-CorpMemoryInfo
Remove-Item -Path Function:\Get-CorpSqlInfo
Get-Command -Module DemoTools
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSqlInfo 

