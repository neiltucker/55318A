﻿$DI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo | Where-Object {$_.DriveType -eq '3'} | ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Disk Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$MI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo | ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Computer System Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$SI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSQLInfo | ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>SQL Server Instance Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"

$Title = "<title>Corporate Server Resources</title>"
$Header = "<h1><b>Server Resources:</b></h1>"
$Head = $Title + $Header
$Body = $DI + $MI + $SI
ConvertTo-Html -Head $Head -Body $Body | Out-File C:\Classfiles\CorpServerReport.html

Invoke-Item C:\Classfiles\CorpServerReport.html
Write-Host "Report saved as: C:\Classfiles\CorpServerReport.html"