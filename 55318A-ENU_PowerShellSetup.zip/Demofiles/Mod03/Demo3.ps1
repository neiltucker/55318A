﻿## Lesson 3: Writing controller scripts that produce reports
## Create report for individual tool scripts
## Create report for multiple tool scripts


# Step 1: Create a report for each of the tool scripts used in the previous exercise.  View each report in a web browser.
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo | ConvertTo-HTML -Property ComputerName, DriveLetter, Size, FreeSpace, DriveType | Out-File C:\Classfiles\corpdiskinfo.html
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo | ConvertTo-HTML -Property ComputerName, Domain, RAM, Manufacturer, Model | Out-File C:\Classfiles\corpmemoryinfo.html 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSQLInfo | ConvertTo-HTML -Property InstanceName, HostDistribution, HostPlatform, Version, ProductLevel | Out-File C:\Classfiles\corpsqlinfo.html 

Invoke-Item C:\Classfiles\corpdiskinfo.html
Invoke-Item C:\Classfiles\corpmemoryinfo.html 
Invoke-Item C:\Classfiles\corpsqlinfo.html 


# Step 2: Create a table for each tool script.
$DI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo | Where-Object {$_.DriveType -eq '3'} | ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Disk Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$MI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo | ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>Computer System Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"
$SI = Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSQLInfo | ConvertTo-HTML -Fragment -As List -PreContent "<h3><b>SQL Server Instance Information:</b></h3>" -PostContent "<h5>$(get-date)</h5>"


# Step 3: Combine the tables (fragments) and include a report title.  Save and view the report (C:\Classfiles\CorpServerResources.html).
$Title = "<title>Corporate Server Resources</title>"
$Header = "<h1><b>Server Resources:</b></h1>"
$Head = $Title + $Header
$Body = $DI + $MI + $SI
ConvertTo-Html -Head $Head -Body $Body | Out-File C:\Classfiles\CorpServerReport.html

Invoke-Item C:\Classfiles\CorpServerReport.html


# Step 4: Save the report generating code from the previous step as C:\Classfiles\CorpServerReport.ps1 and verify that it works.
# A version of the file is saved as C:\Classfiles\Demofiles\Mod03\CorpServerReport.ps1
C:\Classfiles\Demofiles\Mod03\CorpServerReport.ps1


# Step 5: Add the report as an option to the C:\Classfiles\CorpServerResources.ps1 controller script.
# Save the new controller script as C:\Classfiles\CorpServerResourcesandReports.ps1
# A sample version of this script is saved as C:\Classfiles\Demofiles\Mod03\CorpServerResourcesandReports.ps1
C:\Classfiles\Demofiles\Mod03\CorpServerResourcesandReports.ps1


