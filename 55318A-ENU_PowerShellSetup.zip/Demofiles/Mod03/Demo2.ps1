﻿## Lesson 2: Writing controller scripts that show a user interface
## Create and test a controller script

# Step 1: Verify that the script module from the previous exercise was setup properly.
# If there are any errors, repeat the previous exercise.
Remove-Item -Path Function:\Get-CorpDiskInfo
Remove-Item -Path Function:\Get-CorpMemoryInfo
Remove-Item -Path Function:\Get-CorpSqlInfo
Get-Command -Module DemoTools
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo 
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSqlInfo 


# Step 2: Create and test the code that will be used for the controller script.  
# It will provide options to view server resources in three categories: (1) Logical Disk, (2) Computer System & (3) SQL Server instances
$Continue = $True
While ($Continue) {
    Write-Host "=================================="
    Write-Host "        SERVER RESOURCES          "
    Write-Host "=================================="
    Write-Host "                                  "
    Write-Host "1. Logical Disk                   "
    Write-Host "                                  "
    Write-Host "2. Computer System                "
    Write-Host "                                  "
    Write-Host "3. SQL Server Instances           "
    Write-Host "                                  "
    Write-Host "X. Exit                           "
    Write-Host "                                  "
    $input = Read-Host "Enter selection"
    Switch ($input) {
        "1" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo }
        "2" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo }
        "3" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSQLInfo }
        "X" {$Continue = $False}
        default {Write-Warning "Invalid Selection.  Try again."}
    }
}


# Step 3: Save the code as a script name C:\Classfiles\CorpServerResources.ps1 and verify that it works.
C:\Classfiles\CorpServerResources.ps1
