﻿$Continue = $True
While ($Continue) {
    Write-Host "=================================="
    Write-Host "        SERVER RESOURCES          "
    Write-Host "=================================="
    Write-Host "                                  "
    Write-Host "1. Logical Disk                   "
    Write-Host "                                  "
    Write-Host "2. Computer System                "
    Write-Host "                                  "
    Write-Host "3. SQL Server Instances           "
    Write-Host "                                  "
    Write-Host "4. Server Resources Report        "
    Write-Host "                                  "
    Write-Host "X. Exit                           "
    Write-Host "                                  "
    $input = Read-Host "Enter selection"
    Switch ($input) {
        "1" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpDiskInfo }
        "2" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpMemoryInfo }
        "3" {Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSQLInfo }
        "4" {C:\Classfiles\Demofiles\Mod03\CorpServerReport.ps1 }
        "X" {$Continue = $False }
        default {Write-Warning "Invalid Selection.  Try again." }
    }
}

