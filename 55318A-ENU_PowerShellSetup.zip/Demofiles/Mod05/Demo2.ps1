﻿## Lesson 2: Working with JSON formatted data
## Reading and saving JSON files

# Step 1: Read 10 records from a SQL Server database table (AdventureWorks2019.Sales.vSalesPerson) and save the record as a JSON formatted file.
# Note: You must first restore the AdventureWorks2019 database from a backup using the provided script.
# Note: Make sure the database is not in use before running the script.  If necessary, delete the existing database using SSMS.
C:\Classfiles\AdventureWorks_Install.ps1

$SalesTeam = Read-SqlViewData -ServerInstance $env:ComputerName -DatabaseName "AdventureWorks2019"  -SchemaName "Sales" -ViewName "vSalesPerson" -TopN 10 | `
 Select-Object FirstName,Lastname,PhoneNumber,EmailAddress
$SalesTeam
$SalesTeam | ConvertTo-Json |  Out-File C:\Classfiles\demosalesteam1.json 
$SalesTeam 
Get-Content -Path C:\Classfiles\demosalesteam1.json 


# Step 2: Edit the email addresses for each record to substitute "adventure-works.com" with "contoso.com".  Save the updated information to a new JSON file.  
$SalesTeam
Foreach ($e in $SalesTeam) {$e.EmailAddress = $e.EmailAddress -Replace "adventure-works.com", "contoso.com"}
$SalesTeam 
$SalesTeam | ConvertTo-Json |  Out-File C:\Classfiles\demosalesteam2.json 


# Step 3: Convert the new JSON file to a PowerShell object variable. 
$DemoSalesTeam = Get-Content -Path C:\Classfiles\demosalesteam2.json | ConvertFrom-Json
$DemoSalesTeam


# Step 4: Create a new table in the "AdventureWorks2019" database named "DemoSalesTeam" in the "Sales" schema.
# Verify the new JSON file uses "contoso.com" as the new domain suffix for email addresses
Get-Content -Path C:\Classfiles\demosalesteam2.json | ConvertFrom-Json

# Create a query to pull data directly from a JSON file
$Query = "SELECT s.* FROM OPENROWSET(BULK N'\\$env:ComputerName\c$\Classfiles\demosalesteam2.json', SINGLE_NCLOB) AS JSON `
          CROSS APPLY OPENJSON(BulkColumn) WITH(FirstName NVARCHAR(50), LastName NVARCHAR(50), EmailAddress NVARCHAR(50), PhoneNumber NVARCHAR(50) `
		  ) AS s"
Invoke-Sqlcmd -ServerInstance $env:ComputerName -Database "AdventureWorks2019" -Query $Query

# Insert records into a newly created table
$Insert = "SELECT s.* INTO Sales.DemoSalesTeam FROM OPENROWSET(BULK N'\\$env:ComputerName\c$\Classfiles\demosalesteam2.json', SINGLE_NCLOB) AS JSON `
          CROSS APPLY OPENJSON(BulkColumn) WITH(FirstName NVARCHAR(50), LastName NVARCHAR(50), EmailAddress NVARCHAR(50), PhoneNumber NVARCHAR(50) `
		  ) AS s"
Invoke-Sqlcmd -ServerInstance $env:ComputerName -Database "AdventureWorks2019" -Query $Insert

# Query the database table to verify that the insert operation succeeded.
Read-SqlTableData -ServerInstance $env:ComputerName -DatabaseName "AdventureWorks2019"  -SchemaName "Sales" -TableName "DemoSalesTeam"

