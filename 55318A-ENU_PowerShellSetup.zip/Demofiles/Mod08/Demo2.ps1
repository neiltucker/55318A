﻿## Lesson 2: Running Windows PowerShell Workflows
## Create and run Windows PowerShell Workflows on LON-SRV1
## These steps should be run from LON-SRV1

# Step 1: Create a workflow named Start-SMTP with one activity to start the SMTP service.
# Do not execute the workflow in this step.
Workflow Start-SMTP { 
 [CmdletBinding()] 
 Param 
 ( 
 [Parameter(Mandatory=$True)]
 [String[]]$ComputerName
 )
 foreach ($computer in $ComputerName)
   {
   Get-Service -PSComputerName $computer -Name "SMTPSVC" | Start-Service
   Write-Output "SMTP Service started on: $computer"
   }
} 

gcm Start-SMTP 
Get-Command -CommandType Workflow


# Step 2: Review the code generated for Start-SMTP by the workflow and compare it to the code in step 1.
Get-Content C:\Classfiles\DemoStartSMTP.ps1 
Get-Content Function:\Start-SMTP


# Step 3: Save the workflow created in step 1 to a script named C:\Classfiles\DemoStartSMTP.ps1
# Sample DemoStartSMTP.ps1 script is in the C:\Classfiles\Tools folder.
Get-Content C:\Classfiles\DemoStartSMTP.ps1


# Step 4: Stop the SMTP service on the local server.
Get-Service -Name "SMTPSVC" | Stop-Service
Get-Service -Name "SMTPSVC"


# Step 5: Create a PowerShell session on the LON-SRV1 using any valid workflow configuration available.
# To use the builtin workflow session, run the command: Enter-PSSession -ComputerName LON-SRV1 -ConfigurationName Microsoft.PowerShell.Workflow.
# New-PSWorkflowSession always uses the builtin configuration.  It is the same as running New-PSSession with Microsoft.PowerShell.Workflow as the configuration name option.
Get-PSSessionConfiguration -Name "*workflow*" | Select-Object Name, PSVersion, Permission
$WFServer = New-PSSession -ComputerName LON-SRV1 -ConfigurationName "WorkflowAdmin" 
Invoke-Command $WFServer {Import-Module -Name C:\Classfiles\DemoStartSMTP.ps1}
Invoke-Command $WFServer {Start-SMTP -ComputerName LON-SRV1 -AsJob -JobName "StartSMTPJob"}
Invoke-Command $WFServer {Get-Job} 
Invoke-Command $WFServer {Receive-Job -Name "StartSMTPJob"} 

# Step 6: Verify that the SMTP service was started.  Remove the workflow session.
Get-Service -Name "SMTPSVC"
Remove-PSSession -Session $WFServer
