﻿## Lesson 1: Understanding Windows PowerShell Workflow
## Configuring the workflow environment

# Step 1: Configure the options for a new workflow session with the following options: Process Timeout: 15 seconds, Maximum Activity Processes: 10 and Maximum Sessions Per Workflow: 10 
# Assign the configuration to a variable
$wf = New-PSWorkflowExecutionOption -ActivityProcessIdleTimeoutSec 30 -MaxActivityProcesses 10 -MaxSessionsPerWorkflow 10 


# Step 2: Register a new session with the new configuration and give it the name "WorkflowAdmin"
Register-PSSessionConfiguration -Name WorkflowAdmin -SessionTypeOption $wf -Force


# Step 3: List the details of the default workflow sessions and the new session.
Get-PSSessionConfiguration | Where {$_.Name -like "*workflow*"} | Select-Object Name, ActivityProcessIdleTimeoutSec, MaxActivityProcesses, MaxSessionsPerWorkflow


# Step 4: Make the new session the default session. 
# Note: The session name could also have been used by referring to it by name when creating a new session (e.g., New-PSSession -ComputerName LON-SRV1 -ConfigurationName WorkflowAdmin)
$PSSessionConfigurationName
$PSSessionConfigurationName = "WorkflowAdmin"
$PSSessionConfigurationName

# Step 5: Create a new session on the local server and use it to get a list of running services.
$ws = New-PSSession -ComputerName LON-SRV1
Enter-PSSession -Session $ws 
Get-Service | Where {$_.Status -eq "Running"}
