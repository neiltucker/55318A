﻿## Lesson 2: Handling errors in a script
## Adding error handling code to scripts and functions
## Adding error message data to text files

# Step 1: Use the Trap statement to prevent a function from displaying invalid data.
function Get-CorpBIOSInfo1 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Trap { Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop }
    $BI
}

Get-CorpBIOSInfo1
# Try removing the Trap statement to see how the function runs.  The terminating error will prevent the viewing of any data.


# Step 2: Use the Try/Catch statement to prevent a function from displaying invalid data.
function Get-CorpBIOSInfo2 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Try {Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop}
    Catch {Write-Output "There was an error writing BIOS information to the Event Log."}
    Finally {$BI}
}

Get-CorpBIOSInfo2


# Step 3: Write error information to a text file
function Get-CorpBIOSInfo3 {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        $ComputerName = $env:ComputerName
    )
    $FilePath ="C:\Classfiles\Mod04Demo2Step3.log"
    $BI = Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName 
    Try {Write-EventLog -Logname Application -Source "MyBIOSInfo" -EventID 3001 -Message "Computer: $BI.PSComputerName BIOS Serial Name: $BI.SerialNumber" -EA Stop}
    Catch {Write-Output "There was an error writing BIOS information to the Event Log."
           $_ | Out-File -FilePath $FilePath -Append
          }
    Finally {$BI}
}

Get-CorpBIOSInfo3
# Check the log file in the location specified by the $FilePath variable
