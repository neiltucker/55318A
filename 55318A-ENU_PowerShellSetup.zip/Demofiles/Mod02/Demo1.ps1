﻿## Lesson 1: Using .NET Framework in PowerShell
## Use .NET Framework namespaces and classes
## Note: WMI can act as a guide to finding .NET Framework objects and classes, but they won't always match perfectly.
## Some efforts have been made to create a comprehensive list of all .NET Framework classes, but none is complete.  
## Reference: https://dotnet.microsoft.com or http://www.cheat-sheets.org/saved-copy/NETFX4-Poster.pdf

# Step 1: Verify the version of .NET Framework installed.  Use PowerShell and .NET Framework to get process information about the Notepad application.
# Getting the TypeName of an object using Get-Member can help to locagte the correct .NET namespace to use
# (Get-Process | GM).count vs (Get-Process | GM -Force).count vs (Get-Process | GM -View Extended).count vs (Get-Process | Where isSettable).count
(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Release

Start-Process -FilePath Notepad
Get-Process -Name NotePad
Stop-Process -Name Notepad

[System.Diagnostics.Process]::Start("Notepad")
[System.Diagnostics.Process]::GetProcessesByName("Notepad")
[System.Diagnostics.Process]::GetProcessesByName("Notepad").Kill()


# Step 2: List information for your C: Drive using WMI and .NET Framework.
Get-WmiObject -Class Win32_LogicalDisk -Filter 'DeviceID="C:"'
Get-WmiObject -Class Win32_LogicalDisk -Filter 'DeviceID="C:"' | Get-Member

[System.Management.ManagementObject]("Win32_LogicalDisk.DeviceID='C:'")


# Step 3: List total RAM on the computer using WMI and .NET Framework
Get-CimInstance -Class Win32_ComputerSystem -Filter 'Name="lon-srv1"'

[System.Management.ManagementObject]("Win32_ComputerSystem.Name='LON-SRV1'") | Select-Object Name, TotalPhysicalMemory


# Step 4: List SQL Server service information using Powershell cmdlets and .NET Framework
Get-Service -Name MSSQLSERVER
Get-Service -Name "MSSQLSERVER" | GM

[System.ServiceProcess.ServiceController]::GetServices() | Where {$_.ServiceName -eq "MSSQLSERVER"} 


# Step 5: Use .NET class information to get data about the computer and perform mathematical calculations
# Note: Optionally, if you have access to a class provided Microsoft Azure subscription, run these commands in a PowerShell "Cloud Shell" console
# Note: If time permits, try running the equivalent PowerShell cmdlet for each of the commands marked with an asterisk (*).  Both on the class server and in Microsoft Azure Cloud Shell
[DateTime]::Now   *
[TimeZone]::CurrentTimeZone
[MATH]::Sqrt(81)
[MATH]::Round(21.56)
[MATH]::Abs(100 - 20 * 5 + 1)
[MATH]::Pow(5,2)
[MATH]::Min(5,10)
[MATH]::Max(5,10)
[Convert]::ToInt64("25") + 75
[Convert]::ToString(25) + " dollars"
[System.Environment]::MachineName   *
[System.Environment]::UserDomainName
[System.Environment]::UserName   *
[System.Environment]::OSVersion   *
[System.Environment]::Is64BitOperatingSystem
[System.Environment]::GetLogicalDrives()   *
[System.Environment]::GetEnvironmentVariables()   *
[System.Environment]::GetEnvironmentVariable("CurrentDirectory")
[System.Environment]::SetEnvironmentVariable("CurrentDirectory", "C:\Classfiles")
[System.Environment]::GetEnvironmentVariable("CurrentDirectory")


# Step 6: Use a .NET class to connect to the local instance of SQL Server and run a query.
$query = "SELECT * FROM sys.tables"
$connection = New-Object -TypeName System.Data.SqlClient.SqlConnection
$connection.ConnectionString = "Server=localhost; Database=master; Trusted_Connection=True;"
$sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $connection)
$connection.Open()
$reader = $sqlcmd.ExecuteReader()
$output = @()
While ($reader.Read())
    {
        $row = @{}
        For ($i = 0; $i -lt $reader.FieldCount; $i++)
        {
            $row[$reader.GetName($i)] = $reader.GetValue($i)
        }
        $output += New-Object PSObject -Property $row            
    }
$connection.Close()

$output
$output | Select-Object Name, Type_Desc

