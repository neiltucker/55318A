﻿## Lesson 1: Using REST API in PowerShell
## Using REST API to manage IIS websites

# Step 1: Verify IIS is installed on the server.
$WebServer = Get-WindowsFeature "Web-Server"
if(!$WebServer.Installed){Install-WindowsFeature $WebServer -IncludeManagementTools -IncludeAllSubFeature}

# Step 2: Query IIS website API
$APIUrl = "http://" + [System.Net.Dns]::GetHostByName($env:computerName).hostname
Invoke-WebRequest -Uri $APIUrl -UseBasicParsing
$IISAPI = Invoke-WebRequest -Uri $APIUrl -UseBasicParsing
$IISAPI.Content

# Step 3: Perform this step only if Internet access is available on the system.  Query PowerShell Blog.
# Note: This step may also be done in a Microsoft Azure Cloud Shell console if an Azure subscription was provided with the class.
$PowerShellBlogs = "https://blogs.msdn.microsoft.com/powershell/feed/"
Invoke-RestMethod -Uri $PowerShellBlogs
$BlogUrl = Invoke-RestMethod -Uri $PowerShellBlogs
$BlogUrl | Select-Object Title, Link 
$BlogUrl | Select-Object Title, Link | ConvertTo-Json -OutVariable BlogJson
$BlogJson
$BlogJson | Out-File output.json
$BlogUrl | Select-Object Title, Link | ConvertTo-CSV -NoTypeInformation -OutVariable BlogCSV
$BlogCSV
$BlogCSV | Out-File output.csv
$BlogUrl | Select-Object Title, Link | ConvertTo-XML -OutVariable BlogXML 
$BlogXML.innerXml 
$BlogXML.innerXml | Out-File output.xml


