﻿## Lesson 1: Debugging in Windows PowerShell
## Using PowerShell ISE debug features

# Step 0: The function in this step will be used for the following steps. 
function Get-CorpSqlInfo7 {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerInstance')]
        [string[]]$ComputerName
    )
    PROCESS {
        Foreach ($computer in $ComputerName) {
            $instance = Get-SqlInstance -ServerInstance $computer
            foreach ($i in $instance) {
                $properties = @{'InstanceName' = $computer;
                                'Version' = $i.version;
                                'ProductLevel' = $i.productlevel;
                                'HostPlatform' = $i.hostplatform;
                                'HostDistribution' = $i.hostdistribution }
                $output = New-Object -TypeName PSObject -Property $properties
                Write-Output $output
            }
        }
    }
}

Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpSqlInfo7


# Step 1: Create breakpoints at line 10, for the New-Object command and the variables $i & $output.  Verify that the breakpoints are active.
# Set-PSBreakpoint -Line 10 -Script C:\Classfiles\Demofiles\Mod07\Demo1.ps1
# Set-PSBreakpoint -Variable i, output
# Set-PSBreakpoint -Command New-Object
# Get-PSBreakpoint


# Step 2: Use F5 (Run/Continue) to debug the code using the breakpoints you created.  
# Stop at each break point and verify the values of the varuables: $i, $output $ComputerName, $computer, $properties
# Hover over the variable name or type it in the Console to see its value at each breakpoint.


# Step 3: Disable both variable breakpoints and debug the code again with only the line breakpoint.
# Get-PSBreakPoint -Variable i, output | Disable-PSBreakpoint 
# Get-PSBreakpoint | Format-Table ID, Script, Line, Variable, Enabled, Action -AutoSize


# Step 4: Delete all breakpoints.
# Get-PSBreakpoint | Remove-PSBreakpoint
# Get-PSBreakpoint
