﻿function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Write-Verbose -Message "Now connecting to $ComputerName" -Verbose
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName 
}
