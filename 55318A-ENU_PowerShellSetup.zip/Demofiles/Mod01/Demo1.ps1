## Lesson 1: Converting a command into a function
## Create a function to display computer hardware information for a specified computer

# Step 1: Test the command and choose option(s) to be parameterized.
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName localhost
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName lon-srv1, lon-dc1
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $env:computername


# Step 2: Use a basic parameter block to specify an optional parameter for -ComputerName
Param(
    [string]$ComputerName = 'lon-dc1'
)
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName

Param(
    [array]$ComputerName = @('lon-srv1','lon-dc1')
)
Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName


# Step 3: Create the function and add CmdletBinding capabilities
# Note: We will discuss ValueFromPipeline & ValueFromPipelineByPropertyName in a later lesson
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName 
}


# Step 4: Test the previous function definition by executing it in PowerShell ISE
Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | ForEach-Object {Get-CorpCompSysInfo -ComputerName $_.ComputerName}


# Step 5: Test the function variable $ComputerName with and without dot-sourcing
Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
$ComputerName

. Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
$ComputerName 


Note:  Dot sourcing is often used as a temporary solution as importing the functions or using script modules is more efficient 




