﻿## Lesson 3: Defining parameter attributes
## Define and validate parameter attributes

# Step 1: Remove the original function definition for Get-CorpCompSysInfo from memory
Get-Item -Path Function:\Get-CorpCompSysInfo
Remove-Item -Path Function:\Get-CorpCompSysInfo


# Step 2: Define an advanced function with a string parameter
# Note: Some advanced parameter options require parameters with specific data types.
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
}

Get-CorpCompSysInfo
Get-CorpCompSysInfo -Verbose


# Step 3: Make the parameter mandatory
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
}

Get-CorpCompSysInfo


# Step 4: Add a help message to the mandatory parameter
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
}

# When prompted for the computer name, make sure to specify "!?" to see the help message.
Get-CorpCompSysInfo


# Step 5: Create an alias for the parameter
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [Alias('ServerName')]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
}

# Test the alias
Get-CorpCompSysInfo -ServerName lon-dc1


# Step 6: Add a second Parameter
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [Alias('ServerName')]
        [string]$ComputerName,
        [Parameter(Mandatory=$True,HelpMessage='This is a test parameter')]
        [int]$Parameter2
    )
    Write-Verbose "Connect to: $ComputerName"
    Write-Verbose "The second parameter is: $Parameter2"
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName 
}

# Test the second parameter.  Try entering a non-integer value.
Get-CorpCompSysInfo -Verbose


# Step 7: Validate the input using the ValidateLength attribute
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name being queried')]
        [Alias('ServerName')]
        [ValidateLength(3,63)]
        [string]$ComputerName
    )
    Write-Verbose "Connect to: $ComputerName"
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName 
}

# Use a computer name with less than three (3) characters to test the ValidateLength attribute
Get-CorpCompSysInfo -ComputerName 'lo'
Get-CorpCompSysInfo -ComputerName 'lon'
Get-CorpCompSysInfo -ComputerName 'lon-dc1'


# Step 8: Accept multiple computer names in the function
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name(s) being queried')]
        [Alias('ServerName')]
        [ValidateLength(3,63)]
        [string[]]$ComputerName
    )
    foreach ($Computer in $ComputerName) {
        Write-Verbose "Connect to: $ComputerName"
        Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $Computer 
    }
}

# Test the foreach configuration by inputing two computer names (lon-dc1 & lon-srv1)
Get-CorpCompSysInfo 


# Step 9: Save the previous function as the new DemoTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools folder
New-Item -Path $UserModuleFolder"\DemoTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools file
Copy-Item -Path C:\Classfiles\Demofiles\Mod01\DemoToolsv3.ps1 -Destination $UserModuleFolder"\DemoTools\DemoTools.psm1"

# Test the updated DemoTools module script.  
# When prompted for the computer name, make sure to specify "!?" to see the help messages.
# Specify multiple computers names (lon-dc1, lon-srv1)
Remove-Module DemoTools
Remove-Item -Path Function:\Get-CorpCompSysInfo
Get-CorpCompSysInfo 
