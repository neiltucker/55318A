﻿function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,HelpMessage='Computer name(s) being queried')]
        [Alias('ServerName')]
        [ValidateLength(3,63)]
        [string[]]$ComputerName
    )
    foreach ($Computer in $ComputerName) {
        Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $Computer 
    }
}

