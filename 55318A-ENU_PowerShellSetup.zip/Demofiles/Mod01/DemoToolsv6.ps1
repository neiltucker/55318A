﻿function Get-CorpCompSysInfo {
<#
.SYNOPSIS
Retrieve computer hardware information.
.DESCRIPTION
Use the CIM instances of a class to gather information about network computers.
.PARAMETER ComputerName
The name of the computer(s) from which you want hardware data.
.EXAMPLE
Get-CorpCompSysInfo -ComputerName LON-SRV1
This command will gather hardware details from the LON-SRV1 computer.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}

