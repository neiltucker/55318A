﻿function Get-CorpCompSysInfo {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipelineByPropertyName=$True)]
        $ComputerName = $env:ComputerName
    )
    Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName 
}

