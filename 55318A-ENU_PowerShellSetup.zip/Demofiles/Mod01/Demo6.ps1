﻿## Lesson 6: Using comment-based Help
## Add comment-based Help to a function

# Step 1: Remove the original function definitions from memory
Get-Item -Path Function:\Get-CorpCompSysInfo
Remove-Item -Path Function:\Get-CorpCompSysInfo


# Step 2: Create a function that uses comment-based Help.  This example puts the code at the beginning of the function.
# Additional information about comment-based Help can be found using: help about_comment_based_help
function Get-CorpCompSysInfo {
<#
.SYNOPSIS
Retrieve computer hardware information.
.DESCRIPTION
Use the CIM instances of a class to gather information about network computers.
.PARAMETER ComputerName
The name of the computer(s) from which you want hardware data.
.EXAMPLE
Get-CorpCompSysInfo -ComputerName LON-SRV1
This command will gather hardware details about the LON-SRV1 computer.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}


# Step 3: Test the comment-based Help for the function
Get-Help Get-CorpCompSysInfo 
Get-Help Get-CorpCompSysInfo -Detailed
Get-Help Get-CorpCompSysInfo -Examples


# Step 4: Save the previous function as the new DemoTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools folder
New-Item -Path $UserModuleFolder"\DemoTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools file
Copy-Item -Path C:\Classfiles\Demofiles\Mod01\DemoToolsv6.ps1 -Destination $UserModuleFolder"\DemoTools\DemoTools.psm1"

# Test the updated DemoTools module script.  
Remove-Module DemoTools
Remove-Item -Path Function:\Get-CorpCompSysInfo
Get-Help Get-CorpCompSysInfo 
Get-Help Get-CorpCompSysInfo -Detailed
Get-Help Get-CorpCompSysInfo -Examples

