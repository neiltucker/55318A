﻿function Get-CorpCompSysInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    BEGIN {
        Write-Output "BEGIN script block: This function accepts computer names and provides the total physical memory available on the system:"
        Write-Output "Computer names processed in the BEGIN script block: $ComputerName"
    }
    PROCESS {
        Write-Output "PROCESS script block.  Connecting to: $ComputerName"
        Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
    }
    END {
        Write-Output "END script block: "
        Write-Output "The last computer name processed is: $ComputerName"
    }
}

