﻿## Lesson 4: Writing functions to accept pipeline input
## Processing pipeline vs non-pipeline parameter inputs

# Step 1: Remove the original function definitions from memory
Get-Item -Path Function:\Get-CorpCompSysInfo
Remove-Item -Path Function:\Get-CorpCompSysInfo


# Step 2: Use the ValueFromPipelineByPropertyName option to use parameter names in the pipeline
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    ForEach ($Computer in $ComputerName) {
        Write-Output "Connecting to: $Computer"
        Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $Computer
    }
}

Get-CorpCompSysInfo
Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpCompSysInfo


# Step 3: Duplicate the previous function using a PROCESS block
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        Write-Output "Connecting to: $ComputerName"
        Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
    }
}

Get-CorpCompSysInfo
Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpCompSysInfo


# Step 4: Use all three blocks for this function (BEGIN, PROCESS & END)
function Get-CorpCompSysInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    BEGIN {
        Write-Output "BEGIN script block: This function accepts computer names and provides the total physical memory available on the system:"
        Write-Output "Computer names processed in the BEGIN script block: $ComputerName"
    }
    PROCESS {
        Write-Output "PROCESS script block.  Connecting to: $ComputerName"
        Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName
    }
    END {
        Write-Output "END script block: "
        Write-Output "The last computer name processed is: $ComputerName"
    }
}

Get-CorpCompSysInfo
Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpCompSysInfo


# Step 5: Save the previous function as the new DemoTools.psm1 file
# The path for $UserModuleFolder should point to $env:UserProfile + "\Documents\WindowsPowerShell\Modules\"
# Create the PSModulePath folder
$env:PSModulePath -Split ";"
$UserModuleFolder = ($env:PSModulePath -Split ";")[0]
New-Item -Path $UserModuleFolder -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools folder
New-Item -Path $UserModuleFolder"\DemoTools" -ItemType "Directory" -Force -ErrorAction SilentlyContinue

# Create the DemoTools file
Copy-Item -Path C:\Classfiles\Demofiles\Mod01\DemoToolsv4.ps1 -Destination $UserModuleFolder"\DemoTools\DemoTools.psm1"

# Test the updated DemoTools module script.  
# When prompted for the computer name, make sure to specify "!?" to see the help messages.
# Specify multiple computers names (lon-dc1, lon-srv1)
Remove-Module DemoTools
Remove-Item -Path Function:\Get-CorpCompSysInfo
Get-CorpCompSysInfo 
Get-CorpCompSysInfo -ComputerName lon-srv1, lon-dc1
Import-CSV C:\Classfiles\ComputerNames.txt | Get-CorpCompSysInfo
