﻿function Get-CorpCompSysInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('ServerName')]
        [string[]]$ComputerName
    )
    PROCESS {
        ForEach ($Computer in $ComputerName) {
            $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Computer
            $cs = Get-CimInstance –ClassName Win32_ComputerSystem –ComputerName $Computer 
            $Properties = @{'ComputerName'=$Computer; 
                'OSVersion' = $os.Version;
                'RAM' = $cs.TotalPhysicalMemory; 
                'Manufacturer' = $cs.Manufacturer; 
                'Model' = $cs.Model} 
            $Output = New-Object -TypeName PSObject -Property $Properties
            Write-Output $Output
            }
    }
}

