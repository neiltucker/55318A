﻿## Lesson 1: Implementing DSC
## DSC configuraiton files and resources

# Step 1: Check the DSCLocalConfiguration mode setting for LON-SRV1
Get-DscLocalConfigurationManager


# Step 2: Create a DSC configuration file that will change the DSCLocalConfiguration mode to "ApplyandAutoCorrect".  
# Review the DscLocalConfig.ps1 and DscMode.ps1 scripts before continuing.
C:\Classfiles\DscMode.ps1
Get-DscLocalConfigurationManager


# Step 3: Review the C:\Classfiles\AutoCorrectConfig directory.  This is the name assigned to the configuration in the DscLocalConfig.ps1 file.
# It will store the MOF file for the local server.  Take note of the ConfigurationMode.
Get-ChildItem C:\Classfiles\AutoCorrectConfig
Get-Content C:\Classfiles\AutoCorrectConfig\*.mof


# Step 4: Update the DSC configuration and verify the change to the ConfigurationMode.
Set-WSManQuickConfig -Force
Set-DscLocalConfigurationManager -Path C:\Classfiles\AutoCorrectConfig
Get-DscLocalConfigurationManager
 

# Step 5: Install the Print-Services and Storage-Replica features on LON-SRV1 using DSC
# First, verify that the features are not already installed.
# Review the DscLocalPrintServer.ps1 and DscLocalPrintAndStore.ps1 scripts before continuing.
# Ignore any request to reboot the system.
Get-WindowsFeature "Print-Services", "Storage-Replica"

Set-Location -Path C:\Classfiles

Configuration PrintAndStore {
    param(
        [string[]]$ComputerName
    )
    Import-DscResource –ModuleName "PSDesiredStateConfiguration"
    Node $ComputerName {
        WindowsFeatureSet PrintAndStorage {
            Name   = @("Print-Services", "Storage-Replica")
            Ensure = "Present"
            IncludeAllSubFeature = $True
        }
     }
}

PrintAndStore -ComputerName LON-SRV1

Get-Content C:\Classfiles\PrintAndStore\*.mof

Start-DscConfiguration -Path C:\Classfiles\PrintAndStore -Wait -Verbose -Force -ComputerName LON-SRV1
Get-WindowsFeature "Print-Services", "Storage-Replica"


