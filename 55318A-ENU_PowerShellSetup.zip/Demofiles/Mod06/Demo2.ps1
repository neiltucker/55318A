﻿## Lesson 2: Implementing JEA
## Configuring and using JEA for DNS Administration on LON-SRV1

# Step 1: Create a new JEA role file with the name C:\Classfiles\DNSAdmin.psrc 
Set-Location C:\Classfiles
New-PSRoleCapabilityFile -Path C:\Classfiles\DNSAdmin.psrc 


# Step 2: Edit the DNSAdmin.psrc file in Notepad to change and enable the ModulesToImport field.
# Enable parameters by removing the leading '#' ahead of the parameter setting 
# A sample DNSAdmin.psrc file is in the C:\Classfiles\Tools folder 
ModulesToImport = 'DNSServer'
Get-Content C:\Classfiles\DNSAdmin.psrc
Get-Content C:\Classfiles\DNSAdmin.psrc | Select-String -Pattern "#" -NotMatch


# Step 3: Save the updated role capabilities script to the "RoleCapabilities" folder.
$ModuleFolder = Join-Path -Path $env:ProgramFiles -ChildPath "WindowsPowerShell\Modules\ContosoJEA"
$RCFolder = Join-Path -Path $ModuleFolder -ChildPath "RoleCapabilities"
New-Item -ItemType Directory -Path $RCFolder -ErrorAction SilentlyContinue

# Create empty script module
New-Item -ItemType File -Path $ModuleFolder -Name "ContosoJEAFunctions.psm1" -ErrorAction SilentlyContinue
New-ModuleManifest -Path $ModuleFolder"\ContosoJEA.psd1" -RootModule "ContosoJEAFunctions.psm1"
Get-ChildItem $ModuleFolder

# Copy RoleCapabilities (PSRC) file and verify it was copied successfully
Copy-Item -Path C:\Classfiles\DNSAdmin.psrc -Destination $RCFolder 
Get-Content $RCFolder"\DNSAdmin.psrc" | Select-String -Pattern "#" -NotMatch


# Step 4: Create and test a new JEA session file with the name C:\Classfiles\DNSAdmin.pssc using the specified parameters.
# The RoleCapabilities parameter will map to the name of the .psrc file
New-PSSessionConfigurationFile -Path C:\Classfiles\DNSAdmin.pssc -SessionType RestrictedRemoteServer -ExecutionPolicy Restricted -TranscriptDirectory C:\Classfiles\Transcripts -RunAsVirtualAccount -RoleDefinitions @{'Contoso\Student' = @{RoleCapabilities = 'DNSAdmin'}}
Test-PSSessionConfigurationFile -Path C:\Classfiles\DNSAdmin.pssc
Get-Content -Path C:\Classfiles\DNSAdmin.pssc | Select-String -Pattern "#" -NotMatch


# Step 5: Register the JEA session using the DNSAdmin.pssc file 
# You may need to restart the WinRM service on the LON-DC1 server (e.g., Restart-Service WinRM)
Register-PSSessionConfiguration -Path C:\Classfiles\DNSAdmin.pssc -Name 'DNSAdminJEA'


# Step 6: Test the DNSAdminJEA session.  
Enter-PSSession -ComputerName LON-SRV1 -ConfigurationName 'DNSAdminJEA'

# Test the following commands in the JEADNSAdmin session.  Only the DNSServer module cmdlets will be available.
whoami
dns
Get-DNSServer 
Test-DNSServer 
Get-Service 
Restart-Service


