﻿Set-Location -Path C:\Classfiles
. C:\Classfiles\DSCLocalConfig.ps1
AutoCorrectConfig
