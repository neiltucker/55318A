﻿### Azure setup script for 55318 course Virtual Machine.  This script creates a Windows Server 2019 Domain Controller running SQL Server 2019.  The name of the VM is 55318-LON-DC1.
### Updates to class files can be found on GitHub (https://github.com/neiltucker/55318A). 

### Startup Screen
Clear-Host
Write-Output "Azure setup script for 55318 course Virtual Machine.  This script creates a Windows Server 2019 Domain Controller running SQL Server 2019.  The name of the VM is 55318-LON-DC1."
Write-Output "You must provide your Azure Portal credentials to continue with the setup.  A new Resource Group will be added to your account which will contain all the resources needed for the course VM."
Write-Output "You may ignore Import-Module errors during the initial stage of the setup."
Write-Output "The total setup time will be about 60 minutes (15 minutes for the initial local script configuration + 45 minutes for the remote script configuration on the VM in Azure.  Instructions for connecting to the Azure VM will be provided at the end of the initial script setup on the local computer.  Wait at least 45 minutes before using those instructions to connect to the Azure VM."

### Create Variables
# $SubscriptionName = "Azure Pass"                                     # This variable should be assigned your "Subscription Name"
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"
Set-StrictMode -Version 2.0
$WorkFolder = "C:\Labfiles.55318\"                                     # 55318A-ENU_PowerShellSetup.zip must be in this location
$SetupFiles = "55318A-ENU_PowerShellSetup.zip"
$PSModulesFile = "Modules.zip"
Expand-Archive $SetupFiles $WorkFolder -Force -ErrorAction "SilentlyContinue"
Get-ChildItem -Recurse $WorkFolder | Unblock-File
$AdventureWorksBackup = "AdventureWorks2019.bak"
$AdventureWorksDWBackup = "AdventureWorksDW2019.bak"
Set-Location $WorkFolder
$Location = "EASTUS"
$NamePrefix = "init" + (Get-Date -Format "HHmmss")     			# Replace "init" with your initials
$ResourceGroupName = $namePrefix + "rg"
$StorageAccountName = $namePrefix.tolower() + "sa"                   	# Must be lower case
$SAShare = "55318"
$VMDC = "55318-LON-DC1"
$PublicIPDCName = "PublicIPDC"
$VMSRV = "55318-LON-SRV1"
$PublicIPSRV1Name = "PublicIPSRV1"
$PW = Write-Output 'Pa$$w0rdPa$$w0rd' | ConvertTo-SecureString -AsPlainText -Force     # Password for Administrator account
$AdminCred = New-Object System.Management.Automation.PSCredential("adminz",$PW)
$CSETMP = $WorkFolder + "55318customscriptextension.tmp"
$CSENew = $WorkFolder + "55318cse.new"
$PowerShellCoreSetup = $WorkFolder + "PowerShellCoreSetup.msi"

### Log start time of script
$logFilePrefix = "55318AzureSetup" + (Get-Date -Format "HHmm") ; $logFileSuffix = ".txt" ; $StartTime = Get-Date 
"Create Azure VM (55318-LON-DC1)"   >  $WorkFolder$logFilePrefix$logFileSuffix
"Start Time: " + $StartTime >> $WorkFolder$logFilePrefix$logFileSuffix

### Install PowerShell Modules
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
If (Get-PackageProvider -Name NuGet) {Write-Output "NuGet PackageProvider already installed."} Else {Install-PackageProvider -Name "NuGet" -Force}
If (Get-Module -ListAvailable -Name PowerShellGet) {Write-Output "PowerShellGet module already installed"} Else {Find-Module PowerShellGet -IncludeDependencies | Install-Module -Force}
If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -AllowClobber -Force ; Import-Module -Name SQLServer}
Save-Module -Name PackageManagement -Path $WorkFolder -Repository PSGallery
Save-Module -Name Nuget -Path $WorkFolder -Repository PSGallery
Save-Module -Name PowerShellGet -Path $WorkFolder -Repository PSGallery
Save-Module -Name SQLServer -Path $WorkFolder -Repository PSGallery
# Archive Module Folders
Compress-Archive -Path $WorkFolder"SQLServer",$WorkFolder"PackageManagement",$WorkFolder"PowerShellGet",$WorkFolder"NuGet" -DestinationPath $WorkFolder$PSModulesFile -Force

### Login to Azure
Connect-AzAccount
$SubscriptionName = (Get-AzSubscription)[0].Name
$Subscription = Get-AzSubscription -SubscriptionName $SubscriptionName | Select-AzSubscription

### Download PowerShell version 7
Write-Output "Download PowerShell version 7"
Invoke-WebRequest -Uri https://github.com/PowerShell/PowerShell/releases/download/v7.2.4/PowerShell-7.2.4-win-x64.msi -OutFile $PowerShellCoreSetup

### Download AdventureWorks & AdventureWorksDW backup files
Write-Output "Download AdventureWorks & AdventureWorksDW backup files"
& $WorkFolder\adventureworks_download.ps1
& $WorkFolder\adventureworksdw_download.ps1

### Create Resource Group, Storage Account & Setup Resources
$ResourceGroup = New-AzResourceGroup -Name $ResourceGroupName  -Location $Location
$StorageAccount = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -Location $location -Type Standard_RAGRS
$StorageAccountKey = (Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName)[0].Value
$StorageAccountContext = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey
$FileShare = New-AzStorageShare $SAShare.ToLower() -Context $StorageAccountContext
$BlobShare = New-AzStorageContainer -Name $SAShare.ToLower() -Context $StorageAccountContext -Permission Container -Verbose
# Create Custom Script Extension File (CSE)
Write-Output '### Copy From File Share Using Mapped Network Drive' > $CSENew
Write-Output "`$WorkFolder = '$WorkFolder'" >> $CSENew
Write-Output "`$SAShare = '$SAShare'" >> $CSENew
Write-Output 'New-Item -Path $WorkFolder -Type Directory -Force' >> $CSENew
Write-Output 'Set-Location $WorkFolder' >> $CSENew
Write-Output "`$StorageAccountName = '$StorageAccountName'" >> $CSENew
Write-Output "`$StorageAccountKey = '$StorageAccountKey'" >> $CSENew
Get-Content $CSENew, $CSETMP > 55318customscriptextension.ps1
# File Share
Get-ChildItem $WorkFolder"55318customscriptextension.ps1" | Set-AzStorageFileContent -ShareName $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$SetupFiles | Set-AzStorageFileContent -ShareName $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$PSModulesFile | Set-AzStorageFileContent -ShareName $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$AdventureWorksBackup | Set-AzStorageFileContent -ShareName $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$AdventureWorksDWBackup | Set-AzStorageFileContent -ShareName $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $PowerShellCoreSetup | Set-AzStorageFileContent -ShareName $SAShare -Context $StorageAccountContext -Force
# Blob Containers
Get-ChildItem $WorkFolder"55318customscriptextension.ps1" | Set-AzStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$SetupFiles | Set-AzStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$PSModulesFile | Set-AzStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$AdventureWorksBackup | Set-AzStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $WorkFolder$AdventureWorksDWBackup | Set-AzStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force
Get-ChildItem $PowerShellCoreSetup | Set-AzStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force

### Create Network
$NSGRule1 = New-AzNetworkSecurityRuleConfig -Name "RDPRule" -Protocol Tcp -Direction Inbound -Priority 1001 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 3389 -Access Allow
$NSGRule2 = New-AzNetworkSecurityRuleConfig -Name "MSSQLRule"  -Protocol Tcp -Direction Inbound -Priority 1002 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 1433 -Access Allow
$NSGRule3 = New-AzNetworkSecurityRuleConfig -Name "WinHTTP" -Protocol Tcp -Direction Inbound -Priority 1003 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 5985 -Access Allow
$NSGRule4 = New-AzNetworkSecurityRuleConfig -Name "WinHTTPS"  -Protocol Tcp -Direction Inbound -Priority 1004 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 5986 -Access Allow
$NSG1 = New-AzNetworkSecurityGroup -ResourceGroupName $ResourceGroupName -Location $Location -Name "NSG1" -SecurityRules $NSGRule1,$NSGRule2,$NSGRule3,$NSGRule4 -Force
$Subnet10 = New-AzVirtualNetworkSubnetConfig -Name "Subnet10" -AddressPrefix 192.168.10.0/24
$Subnet20 = New-AzVirtualNetworkSubnetConfig -Name "Subnet20" -AddressPrefix 192.168.20.0/24 
$VirtualNetwork1 = New-AzVirtualNetwork -Name "VirtualNetwork1" -ResourceGroupName $ResourceGroupName -Location $Location -AddressPrefix 192.168.0.0/16 -Subnet $Subnet10, $Subnet20 -Force
$PublicIPDC = New-AzPublicIpAddress -Name $PublicIPDCName -ResourceGroupName $ResourceGroupName -Location $Location -AllocationMethod Static  
$DCNIC1 = New-AzNetworkInterface -Name "DCNIC1" -ResourceGroupName $ResourceGroupName -Location $Location -PrivateIPAddress 192.168.10.100 -SubnetId $VirtualNetwork1.Subnets[0].Id -PublicIpAddressId $PublicIPDC.Id -NetworkSecurityGroupId $NSG1.Id
$DCNIC2 = New-AzNetworkInterface -Name "DCNIC2" -ResourceGroupName $ResourceGroupName -Location $Location -PrivateIPAddress 192.168.20.100 -SubnetId $VirtualNetwork1.Subnets[1].Id -NetworkSecurityGroupId $NSG1.Id
$PublicIPSRV1 = New-AzPublicIpAddress -Name $PublicIPSRV1Name -ResourceGroupName $ResourceGroupName -Location $Location -AllocationMethod Static  
$SRV1NIC1 = New-AzNetworkInterface -Name "SRV1NIC1" -ResourceGroupName $ResourceGroupName -Location $Location -PrivateIPAddress 192.168.10.101 -SubnetId $VirtualNetwork1.Subnets[0].Id -PublicIpAddressId $PublicIPSRV1.Id -NetworkSecurityGroupId $NSG1.Id
$SRV1NIC2 = New-AzNetworkInterface -Name "SRV1NIC2" -ResourceGroupName $ResourceGroupName -Location $Location -PrivateIPAddress 192.168.20.101 -SubnetId $VirtualNetwork1.Subnets[1].Id -NetworkSecurityGroupId $NSG1.Id

### Create VMs
# Domain Controller
$PublisherName = "MicrosoftSQLServer"
$Offer = (Get-AzVMImageOffer -Location $Location -PublisherName $PublisherName | Where-Object {$_.Offer -match "SQL2019-WS2019"})[0].Offer 
$Skus = (Get-AzVMImagesku -Location $Location -PublisherName $PublisherName -Offer $Offer | Where-Object {$_.Skus -match "SQLDEV"})[0].Skus
$VMSize = (Get-AzVMSize -Location $Location | Where-Object {$_.Name -match "Standard_DS2"})[0].Name
$VMDC1 = New-AzVMConfig -VMName $VMDC -VMSize $VMSize
$VMDC1 = Set-AzVMOperatingSystem -VM $VMDC1 -Windows -ComputerName $VMDC -Credential $AdminCred -WinRMHttp -ProvisionVMAgent -EnableAutoUpdate
$VMDC1 = Set-AzVMSourceImage -VM $VMDC1 -PublisherName $PublisherName -Offer $Offer -Skus $Skus -Version "latest"
$VMDC1 = Add-AzVMNetworkInterface -VM $VMDC1 -ID $DCNIC1.Id -Primary
$VMDC1 = Add-AzVMNetworkInterface -VM $VMDC1 -ID $DCNIC2.Id 
$VHDURIDC1 = (Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName).PrimaryEndPoints.Blob.ToString() + "vhddc/VHDDC1.vhd"
$VM1 = Set-AzVMOSDisk -VM $VMDC1 -Name "VHDDC1" -VHDURI $VHDURIDC1 -CreateOption FromImage
New-AzVM -ResourceGroupName $ResourceGroupName -Location $Location -VM $VMDC1 -Verbose
Start-AzVM -Name $VMDC -ResourceGroupName $ResourceGroupName
Set-AzVMCustomScriptExtension -Name "Microsoft.Compute" -TypeHandlerVersion "1.9" -FileName "55318customscriptextension.ps1" -Run "55318customscriptextension.ps1" -ForceRerun $(New-Guid).Guid -ContainerName $SAShare -ResourceGroupName $ResourceGroupName -VMName $VMDC -Location $Location -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey
$PublicIPAddressDC1 = Get-AzPublicIpAddress -Name $PublicIPDCName -ResourceGroupName $ResourceGroupName
Write-Output "The virtual machine has been created and the local machine portion of the setup is finished.  Wait 45 minutes for the remote part of the setup to complete, and then you may login as Adminz by using Remote Desktop Connection to connect to its Public IP address."
Write-Output  "Public IP Address for $VMDC is: " $PublicIPAddressDC1.IpAddress
# Member Server
Write-Output "Pause for 10 minutes before starting setup of domain member server:"
Timeout 600
$PublisherName = "MicrosoftSQLServer"
$Offer = (Get-AzVMImageOffer -Location $Location -PublisherName $PublisherName | Where-Object {$_.Offer -match "SQL2019-WS2019"})[0].Offer 
$Skus = (Get-AzVMImagesku -Location $Location -PublisherName $PublisherName -Offer $Offer | Where-Object {$_.Skus -match "SQLDEV"})[0].Skus
$VMSize = (Get-AzVMSize -Location $Location | Where-Object {$_.Name -match "Standard_DS2"})[0].Name
$VMSRV1 = New-AzVMConfig -VMName $VMSRV -VMSize $VMSize
$VMSRV1 = Set-AzVMOperatingSystem -VM $VMSRV1 -Windows -ComputerName $VMSRV -Credential $AdminCred -WinRMHttp -ProvisionVMAgent -EnableAutoUpdate
$VMSRV1 = Set-AzVMSourceImage -VM $VMSRV1 -PublisherName $PublisherName -Offer $Offer -Skus $Skus -Version "latest"
$VMSRV1 = Add-AzVMNetworkInterface -VM $VMSRV1 -ID $SRV1NIC1.Id -Primary
$VMSRV1 = Add-AzVMNetworkInterface -VM $VMSRV1 -ID $SRV1NIC2.Id 
$VHDURI1 = (Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName).PrimaryEndPoints.Blob.ToString() + "vhdsrv1/VHDSRV1.vhd"
$VMSRV1 = Set-AzVMOSDisk -VM $VMSRV1 -Name "VHDSRV1" -VHDURI $VHDURI1 -CreateOption FromImage
New-AzVM -ResourceGroupName $ResourceGroupName -Location $Location -VM $VMSRV1 -Verbose
Start-AzVM -Name $VMSRV -ResourceGroupName $ResourceGroupName
Set-AzVMCustomScriptExtension -Name "Microsoft.Compute" -TypeHandlerVersion "1.9" -FileName "55318customscriptextension.ps1" -Run "55318customscriptextension.ps1" -ForceRerun $(New-Guid).Guid -ContainerName $SAShare -ResourceGroupName $ResourceGroupName -VMName $VMSRV -Location $Location -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey
$PublicIPAddressSRV1 = Get-AzPublicIpAddress -Name $PublicIPSRV1Name -ResourceGroupName $ResourceGroupName
Write-Output "The virtual machine has been created and the local machine portion of the setup is finished.  Wait 30 minutes for the remote part of the setup to complete, and then you may login as Adminz by using Remote Desktop Connection to connect to its Public IP address."
Write-Output  "Public IP Address for $VMSRV is: " $PublicIPAddressSRV1.IpAddress

### Delete Resources and log end time of script
"55318-LON-DC1   Internet IP:  " + $PublicIPAddressDC1.IPAddress >> $WorkFolder$logFilePrefix$logFileSuffix
"55318-LON-SRV1  Internet IP:  " + $PublicIPAddressSRV1.IPAddress >> $WorkFolder$logFilePrefix$logFileSuffix
"Resource Group Name  :  " + $ResourceGroupName + "   # Delete the Resource Group to remove all Azure resources created by this script (e.g. Remove-AzResourceGroup -Name $ResourceGroupName -Force)"  >> $WorkFolder$logFilePrefix$logFileSuffix
$EndTime = Get-Date ; $et = "55318AzureSetup" + $EndTime.ToString("yyyyMMddHHmm")
"End Time:   " + $EndTime >> $WorkFolder$logFilePrefix$logFileSuffix
"Duration:   " + ($EndTime - $StartTime).TotalMinutes + " (Minutes)" >> $WorkFolder$logFilePrefix$logFileSuffix 
Rename-Item -Path $WorkFolder$logFilePrefix$logFileSuffix -NewName $et$logFileSuffix
Get-Content $et$logFileSuffix
### Remove-AzResourceGroup -Name $ResourceGroupName -Verbose -Force

