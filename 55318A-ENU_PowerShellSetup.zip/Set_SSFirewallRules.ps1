New-NetFirewallRule -DisplayName "SQLServerTCP" -Direction Inbound �Protocol TCP �LocalPort 1433,1434 -Action Allow
New-NetFirewallRule -DisplayName "SQLServerUDP" -Direction Inbound �Protocol UDP �LocalPort 1433,1434 -Action Allow
New-NetFirewallRule -DisplayName "SQLDebugger" -Direction Inbound �Protocol TCP �LocalPort 135 -Action Allow
New-NetFirewallRule -DisplayName "SQLServerOLAPTCP" -Direction Inbound �Protocol TCP �LocalPort 2382,2383 -Action Allow
New-NetFirewallRule -DisplayName "SQLServerOLAPUDP" -Direction Inbound �Protocol UDP �LocalPort 2382,2383 -Action Allow
Set-NetFirewallProfile -DefaultInboundAction Block -DefaultOutboundAction Allow -NotifyOnListen True -AllowUnicastResponseToMulticast True

