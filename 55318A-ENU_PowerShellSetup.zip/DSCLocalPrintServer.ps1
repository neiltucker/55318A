﻿Set-Location -Path C:\Classfiles
. C:\Classfiles\DSCLocalPrintAndStore.ps1
PrintAndStore -ComputerName LON-SRV1, LON-DC1