#  "*****   Change the default location of new data and log files   *****"
invoke-sqlcmd "exec xp_instance_regwrite 'HKEY_LOCAL_MACHINE', 'Software\Microsoft\MSSQLServer\MSSQLServer', 'DefaultData', REG_SZ,'C:\Data\'"
invoke-sqlcmd "exec xp_instance_regwrite 'HKEY_LOCAL_MACHINE', 'Software\Microsoft\MSSQLServer\MSSQLServer', 'DefaultLog', REG_SZ,'C:\Log\'"

#  "*****   Modify the size and auto-grow settings for the Model database   *****"
# invoke-sqlcmd -InputFile C:\Classfiles\Modify_Model.sql
