﻿Configuration PrintAndStore {
    param(
        [string[]]$ComputerName
    )
    Import-DscResource –ModuleName "PSDesiredStateConfiguration"
    Node $ComputerName {
        WindowsFeatureSet PrintAndStorage {
            Name   = @("Print-Services", "Storage-Replica")
            Ensure = "Present"
            IncludeAllSubFeature = $True
        }
     }
}
