# Unzip Setup Files
$Archive = "C:\Labfiles.55318\55318A-ENU_PowerShellSetup.zip"
$WorkFolder = "C:\Labfiles.55318\"
Expand-Archive -LiteralPath $Archive -DestinationPath $WorkFolder -Force
Get-ChildItem -Recurse $WorkFolder | Unblock-File


