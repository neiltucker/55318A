# Generate the Scripts used by Diskpart.exe to manage the Labfiles.VHDX file (LabfilesHD2A.txt & LabfilesHD2B.txt)
# Labfiles.VHDX will be temporarily attached to the host server as the $VHDMP drive

cd $Labfiles
"create vdisk file " + $VMLOC + "\Labfiles_$DC1.VHDX maximum=40960 type=expandable" | Out-File -encoding ASCII $Labfiles\LabfilesHD2A.txt
"select vdisk file " + $VMLOC + "\Labfiles_$DC1.VHDX" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"attach vdisk" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"create partition primary" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"format quick label=Labfiles" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"assign letter=" + $VHDMP | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"exit" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"select vdisk file $VMLOC\labfiles_$DC1.vhdx" | Out-File -encoding ASCII $Labfiles\LabfilesHD2B.txt
"detach vdisk" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2B.txt
"exit" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2B.txt

# Create and mount the Labfiles VHDX file
DISKPART.EXE /s $Labfiles\LabfilesHD2A.txt

# Copy class files to the Labfiles VHDX drive
XCopy *.* $VHDMP\ /s/v/y/Exclude:exclude.txt

# Dismount the Labfiles VHDX drive
DISKPART.EXE /s $Labfiles\LabfilesHD2B.txt
 
# Copy Labfiles.vhdx
Copy $VMLOC\Labfiles_$DC1.vhdx $VMLOC\Labfiles_$SRV1.vhdx -Force -PassThru -ErrorAction Stop
# Copy $VMLOC\Labfiles_$DC1.vhdx $VMLOC\Labfiles_$SRV2.vhdx -Force -PassThru -ErrorAction Stop