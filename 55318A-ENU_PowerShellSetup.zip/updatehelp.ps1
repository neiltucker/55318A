# Update the PowerShell Help Files on the server
Update-Help -SourcePath "C:\Classfiles\PSHelp" -Force
Clear-Host
Write-Output "*****   Update of PowerShell Help complete   *****"
