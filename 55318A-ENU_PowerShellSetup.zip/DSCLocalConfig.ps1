﻿[DSCLocalConfigurationManager()]
Configuration AutoCorrectConfig
{
    Node $env:ComputerName
    {
        Settings
        {
            RefreshMode = 'Push'
            ConfigurationMode = 'ApplyandAutoCorrect'
        }
    }
} 
