-- Change the size and auto-grow settings for the Model database.
-- All newly created databases on this instance will inherit these new settings 
USE Master
GO
ALTER DATABASE Model MODIFY FILE ( NAME = 'modeldev', SIZE=100MB, MAXSIZE=10000MB, FILEGROWTH=100MB)
GO
ALTER DATABASE Model MODIFY FILE ( NAME = 'modellog', SIZE=25MB, MAXSIZE=2500MB, FILEGROWTH=25MB)
GO

