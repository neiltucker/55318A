# Create GPO with PowerShell script execution enabled
New-GPO -Name PowerShellScriptExecution -ErrorAction SilentlyContinue | New-GPLink -Target "dc=contoso,dc=com" -Enforced Yes
Import-GPO -BackupGPOName "PowerShellScriptExecution" -Path C:\Classfiles\Tools -TargetName "PowerShellScriptExecution"

